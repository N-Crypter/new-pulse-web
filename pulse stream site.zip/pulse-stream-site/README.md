# Pulse Stream Media: integrated website (7 hosts, one codebase)

Static site. `src/` holds content and templates, `static/` holds CSS/JS, `assets/` holds processed images and brand files,
`build.py` generates `dist/`, and `vercel.json` maps each hostname to its folder inside `dist/sites/`.

| Host | Folder | Brand |
|---|---|---|
| pulsestream.africa | dist/sites/main | Pulse Stream Media (parent) |
| optic1.pulsestream.africa | dist/sites/optic1 | OPTIC1 Media (photography) |
| tva.pulsestream.africa | dist/sites/tva | The Voice Amplified Podcast |
| tops.pulsestream.africa | dist/sites/tops | Thoughts and Other Problems |
| ron.pulsestream.africa | dist/sites/ron | Ron Wayez |
| charity.pulsestream.africa | dist/sites/charity | The Voice Amplified Charity |
| music.pulsestream.africa | dist/sites/music | Pulse Stream Recording |

## Everyday use (Windows + VS Code)
1. Install Python 3.10+ (`pip install pillow beautifulsoup4 playwright` only if you re-run image tools or tests).
2. Edit content in `src/config.py` (prices, hours, socials, FAQs) or the `src/pages_*.py` files.
3. Run `python build.py`. This regenerates `dist/` and `vercel.json`.
4. Preview locally: `python tools/preview.py 8099`, then open `http://localhost:8099` (main site) or `http://optic1.localhost:8099`, `tva.localhost`, `tops.localhost`, `ron.localhost`, `charity.localhost`, `music.localhost`.
5. Commit and push (or `vercel --prod`). `dist/` is committed, so Vercel needs no build step.

## Adding photos later
Put originals in a safe folder, add an entry to `PHOTOS` in `tools/process_images.py`, run it, then add the key to a gallery list.
Never upload originals into `dist/`.

## Generator note
This is a small purpose-built Python generator, not Astro. The build environment had no internet access, so Astro could not be installed.
The structure (components, data file, one template per page) is easy to move to Astro later.

See `docs/` for DNS, email, payments, SEO, asset audit, testing and the change report.
