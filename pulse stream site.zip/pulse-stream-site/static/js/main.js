(function () {
  'use strict';

  /* Mobile navigation */
  var toggle = document.querySelector('.nav-toggle');
  var panel = document.getElementById('mobile-panel');
  var overlay = document.querySelector('.overlay');
  function setNav(open) {
    if (!panel) return;
    panel.classList.toggle('is-open', open);
    overlay.classList.toggle('is-visible', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.style.overflow = open ? 'hidden' : '';
  }
  if (toggle && panel && overlay) {
    toggle.addEventListener('click', function () { setNav(true); });
    overlay.addEventListener('click', function () { setNav(false); });
    panel.addEventListener('click', function (e) {
      if (e.target.closest('a') || e.target.closest('.close')) setNav(false);
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setNav(false); closeLightbox(); } });
  }

  /* Gallery filters */
  document.querySelectorAll('[data-filters]').forEach(function (bar) {
    var gallery = document.getElementById(bar.getAttribute('data-filters'));
    if (!gallery) return;
    bar.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-filter]');
      if (!btn) return;
      bar.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
      var f = btn.getAttribute('data-filter');
      gallery.querySelectorAll('figure').forEach(function (fig) {
        fig.hidden = !(f === 'all' || fig.getAttribute('data-cat') === f);
      });
    });
  });

  /* Lightbox */
  var lb = document.querySelector('.lightbox');
  var lbImg = lb && lb.querySelector('img');
  var lastTrigger = null;
  function closeLightbox() {
    if (!lb || !lb.classList.contains('is-open')) return;
    lb.classList.remove('is-open');
    if (lastTrigger) lastTrigger.focus();
  }
  if (lb) {
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-full]');
      if (t) {
        lastTrigger = t;
        lbImg.src = t.getAttribute('data-full');
        lbImg.alt = t.getAttribute('data-alt') || '';
        lb.classList.add('is-open');
        lb.querySelector('button').focus();
      } else if (e.target === lb || e.target.closest('.lightbox button')) {
        closeLightbox();
      }
    });
  }

  /* Enquiry forms (no server: validated, then handed to email or WhatsApp) */
  var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var phoneRe = /^\+?[0-9][0-9\s()-]{8,}$/;

  function validate(form) {
    var ok = true;
    form.querySelectorAll('.field').forEach(function (f) {
      var el = f.querySelector('input,select,textarea');
      if (!el) return;
      var v = el.value.trim(), bad = false, msg = f.querySelector('.err');
      if (el.required && v === '') { bad = true; if (msg) msg.textContent = 'This field is required.'; }
      else if (el.type === 'email' && v && !emailRe.test(v)) { bad = true; if (msg) msg.textContent = 'Enter a valid email address.'; }
      else if (el.type === 'tel' && v && !phoneRe.test(v)) { bad = true; if (msg) msg.textContent = 'Enter a valid phone number.'; }
      f.classList.toggle('is-invalid', bad);
      el.setAttribute('aria-invalid', bad ? 'true' : 'false');
      if (bad) ok = false;
    });
    return ok;
  }

  function summary(form) {
    var lines = [];
    form.querySelectorAll('.field').forEach(function (f) {
      var el = f.querySelector('input,select,textarea'), lab = f.querySelector('label');
      if (el && el.value.trim()) lines.push(lab.textContent.replace(' *', '') + ': ' + el.value.trim());
    });
    return lines.join('\n');
  }

  document.querySelectorAll('form[data-enquiry]').forEach(function (form) {
    var success = form.querySelector('.form-success');
    function go(kind) {
      if (!validate(form)) { var first = form.querySelector('.is-invalid input,.is-invalid select,.is-invalid textarea'); if (first) first.focus(); return; }
      var brand = form.getAttribute('data-brand-name');
      var text = 'New enquiry for ' + brand + '\n\n' + summary(form);
      var url;
      if (kind === 'wa') url = 'https://wa.me/' + form.getAttribute('data-wa') + '?text=' + encodeURIComponent(text);
      else url = 'mailto:' + form.getAttribute('data-email') + '?subject=' + encodeURIComponent('Enquiry: ' + brand) + '&body=' + encodeURIComponent(text);
      if (success) {
        success.textContent = kind === 'wa'
          ? 'Thank you. WhatsApp should open with your enquiry ready to send. Please press send there to complete it.'
          : 'Thank you. Your email app should open with your enquiry ready to send. Please press send there to complete it.';
        success.classList.add('is-visible');
      }
      if (kind === 'wa') { window.open(url, '_blank', 'noopener'); } else { window.location.href = url; }
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); go('email'); });
    form.querySelectorAll('[data-send]').forEach(function (b) {
      b.addEventListener('click', function () { go(b.getAttribute('data-send')); });
    });
    form.addEventListener('input', function (e) {
      var f = e.target.closest('.field'); if (f) f.classList.remove('is-invalid');
    });
  });
})();
