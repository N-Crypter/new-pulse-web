# Stage 6: final change report (APPROVED by the owner on 16 Nov 2026; final files saved)

Nothing has been saved over your existing files or published. This is a **new, separate project folder**; your original `index.html`, `Images/` and zip are untouched.

## 1. Summary
A 7-host static website (20 pages) built from one codebase: Pulse Stream Media main site (home, about, services, videography, PA and events, podcast studio rental, pricing, portfolio, FAQ, contact, privacy, terms, 404, coming soon) plus landing pages for OPTIC1 Media, The Voice Amplified Podcast (tva.), Thoughts and Other Problems (tops.), Ron Wayez, The Voice Amplified Charity and Pulse Stream Recording (music.).
Added as requested: floating WhatsApp button on every page, follow/subscribe block on every page, podcast studio rental section on the main page, opening hours, and your address (main, OPTIC1 and Recording only).

## 2-4. Files
- **Modified:** none of your originals.
- **New:** everything in this folder: `src/` (content and templates), `static/css|js`, `assets/images` (88 optimised files) and `assets/brand` (logos, favicons, 7 OG images), `build.py`, `vercel.json`, `dist/` (built site), `tools/` (image processing, validation, tests), `docs/`.
- **Removed or replaced:** the old single-file `index.html` design is replaced by the new pages. Not carried over: Bootstrap and the Elarisse template styling and images, placeholder showreel/foundation blocks, the two JSON-LD blocks with placeholder logo URL, `info@pulsestream.za` and the Gmail address.

## 5-8. Images, copyright, retouching, placement
See `asset-audit-report.md`. 11 of 12 photos used (one exact duplicate skipped), all web-optimised; no metadata present in the originals. Placement: main hero, main portfolio (8) and OPTIC1 hero and gallery (10 plus hero). Podcast, Recording, Ron, Charity and studio-rental sections have no photos available, so they are text-led with no empty image frames.

## 9-12. SEO, subdomains, email, payments
SEO: `seo-report.md`. Subdomains and routing: `deployment-vercel.md`, `dns-xneelo.md`. Email: `email-architecture.md`. Payments: `payments-plan.md` (planned only).

## 13. Testing: what was and was not done
**Performed (local build, Chromium only):**
- Static checks on all 20 pages: 0 issues (one H1, heading order, titles, descriptions, canonicals, Open Graph/Twitter tags, JSON-LD parses, alt text, image dimensions, labelled form fields, 937 links including anchors and cross-brand links, no placeholder or secret strings).
- Browser checks at 1440, 820 and 390 px on 20 pages (60 page-viewport combinations): 0 horizontal overflow, 0 broken images, 0 console errors or failed requests, WhatsApp button visible. Google Fonts requests were excluded because the test machine is offline.
- Interactions: mobile menu open/close/overlay, gallery filters, lightbox, form validation and WhatsApp hand-off, floating button on scroll, per-host robots and sitemaps.
- Local speed sample: CLS 0 and about 50 to 93 KB first-screen weight (not a production Lighthouse result).
**Not performed:** real deployment, host rewrites on Vercel, DNS, HTTPS/HSTS, production Core Web Vitals, social preview scrapers (Facebook, LinkedIn, WhatsApp), Google Rich Results validation, Search Console, Safari/Firefox/real phones, screen readers, email delivery.

## 14. Outstanding issues and decisions for you
1. **Weekend hours:** I show "Saturday and Sunday: by appointment only" (your latest message). Earlier you said weekends close at 6 pm. Confirm.
2. **Social links:** only The Voice Amplified (Facebook, YouTube), Thoughts and Other Problems (Facebook) and Ron (Facebook) were supplied. Pulse Stream, OPTIC1, Recording and the charity have none, so their follow blocks list the available family channels plus WhatsApp.
3. **Prices** are ChatGPT's suggestions, used on your instruction, shown as "from". Please review them. Not VAT-registered is stated.
4. **Mailboxes** do not exist yet; create them before launch.
5. **Generator:** a small custom Python script, not Astro (no internet in my environment). `dist/` is committed, so Vercel needs no build.
6. **Vercel host routing** is logic-tested only; verify on first deployment.
7. **Logos missing** for Ron, Charity and Recording (placeholders in use). The Voice Amplified Podcast colour scheme is my proposal (only a white logo was supplied).
8. **Address on studio rental:** not shown in the podcast studio section (kept off podcast pages); it appears in the footer and contact area of the main site.
9. **Legal text** (privacy and terms) is a plain-language starting point; have it reviewed before relying on it.
10. **Fonts** load from Google Fonts (mentioned in the privacy notice); self-hosting would be faster still.
11. **Payments, booking system and a real form back-end** are planned, not built. Forms hand off to the visitor's email or WhatsApp.
12. Photos: confirm model releases (children, golf-day guests) and that sponsor banners in the event photos are fine to show.

Owner confirmed satisfaction and explicitly authorised saving the final files. Owner also confirmed all supplied images and logos are legally theirs.
