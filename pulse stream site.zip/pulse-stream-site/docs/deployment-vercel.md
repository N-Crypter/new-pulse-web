# Vercel deployment, domains and rollback

Nothing here has been done for you. No DNS or production setting was changed.

## First deployment (preview first)
1. Put this folder in a **new** Git repository (do not overwrite the existing one). `.env` is git-ignored.
2. In Vercel: Add New Project, import the repo. Framework preset: **Other**. Build command: *(empty)*. Output directory: `dist`.
3. Deploy. Open the `*.vercel.app` preview URL. Host-based rewrites only work on the real domains, so the preview shows nothing at `/`
   until the domains are added; check `/sites/main/` to see the main site files.
4. Project, Settings, Domains: add `pulsestream.africa` and each subdomain: `optic1`, `tva`, `tops`, `ron`, `charity`, `music` (all `.pulsestream.africa`).
   Vercel shows the DNS record each needs. Use exactly what Vercel shows.
5. After DNS resolves, Vercel issues HTTPS certificates automatically. Visit each host and confirm the correct brand loads.

## Not tested
The rewrites in `vercel.json` were validated for logic with a local server that mimics them. They have **not** been run on Vercel.
If a host shows the wrong page, check Project, Settings, Domains first, then the rewrite order in `vercel.json`.

## Environment variables
None are needed today. `.env.example` lists names reserved for the future payment feature. Add real values only in Vercel, never in files.

## Rollback
- Fast: Vercel dashboard, Deployments, pick the last good deployment, **Promote to Production** (or "Instant Rollback").
- Code: `git revert <commit>` and push.
- Your previous site is untouched in your original folder and zip.
