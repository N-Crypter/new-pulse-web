# DNS configuration (xneelo): proposal only, nothing applied

Do not change live records until the new project is deployed and you are ready. Take a screenshot or export of the current zone first (rollback).

## Website records
| Host | Type | Value |
|---|---|---|
| pulsestream.africa (apex) | A | the value Vercel shows when you add the domain (historically 76.76.21.21) |
| optic1, tva, tops, ron, charity, music | CNAME | the value Vercel shows (commonly cname.vercel-dns.com) |
| www | CNAME | optional: add `www.pulsestream.africa` in Vercel; `vercel.json` already redirects www to the apex |

The values Vercel displays in the dashboard are authoritative; use those over this table.

## Email records (after choosing a provider, see email-architecture.md)
MX, SPF (TXT), DKIM (TXT or CNAME) and DMARC (TXT) values are issued by the provider. Nothing is invented here.
A DMARC starting point most providers accept: `v=DMARC1; p=none; rua=mailto:<a mailbox you control>`; tighten to `quarantine` later.
Only one SPF record may exist per domain: merge, do not duplicate.

## Google Search Console
Add each host (or one Domain property for pulsestream.africa). Google shows a TXT record; add it at xneelo. Verification is only real once Google confirms it.
