# Asset and copyright audit

Full inventory with SHA-256 hashes: `asset-inventory.csv`. Originals were never modified; they remain in your original folder and zip (hashes recorded for verification).

## Photographs (12 files supplied)
- **Metadata:** all 12 had no EXIF, IPTC, XMP or GPS data (stripped before supply). Nothing further needed removing, and no original copyright notices existed to preserve.
- **Copyright:** metadata cannot prove ownership. All 12 are classed **CLEARED on your statement that you own them**. Recommendations: keep model releases, especially for children and the golf-day guests, and confirm the sponsor banners in the golf-day photos are acceptable to show.
- **Use:** 11 unique photos used; `foto_no_exif (11).jpg` is a byte-identical duplicate of (3) and was skipped.
- **Quality note:** `foto_no_exif (1).jpg` is a WebP file named .jpg at 8024x12060 and only 0.86 MB, so it looks upscaled. It is used only at web sizes.
- **Images from ChatGPT screenshots and the Envato template:** not used (stock/AI/third-party, per the RESTRICTED rule).

## Logos (supplied by you, ownership confirmed)
Pulse Stream, The Voice Amplified Podcast, Thoughts and Other Problems and OPTIC1 Media were used as supplied (cropped/resized only; no redesign).
Ron Wayez, The Voice Amplified Charity and Pulse Stream Recording have no logos: the first two use a text mark and a simple monogram favicon ("RW", "VA"); Recording uses the Pulse Stream logo. Replace when you have logos.

## Retouching performed
Global, conservative only: tone normalisation (auto-contrast, tone preserving) and output sharpening on resize. No face, skin, body or local edits and no generative processing. This is lighter than a manual Lightroom pass; supply your edited versions if you want a different look.

## Owner confirmation
On 16 Nov 2026 the owner confirmed that everything supplied is legally theirs. Remaining recommendation only: keep model releases on file.
