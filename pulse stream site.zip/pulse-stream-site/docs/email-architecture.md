# Email architecture (proposed; none of these mailboxes are confirmed to exist)

The site links to these addresses with `mailto:`. **Each must exist (as a mailbox, alias or forward) before launch or enquiries will bounce.**

| Brand | Address | Suggested type |
|---|---|---|
| Pulse Stream Media | info@, bookings@, accounts@ | Real mailboxes |
| OPTIC1 Media | optic1@ | Alias to bookings@ (or own mailbox) |
| The Voice Amplified Podcast | voiceamplified@, partnerships@ | Aliases |
| Thoughts and Other Problems | thoughts@ | Alias or mailbox |
| Ron Wayez | ron@ | Real mailbox (personal brand) |
| The Voice Amplified Charity | charity@, donations@ | donations@ should be its own mailbox (separate records) |
| Pulse Stream Recording | recording@ | Alias |

`photography@` from the original brief is no longer used: OPTIC1 replaced it.

## Hosting options
1. **Google Workspace** (recommended): per-user paid seats, unlimited aliases, strong spam filtering, simple DKIM/DMARC.
2. **Microsoft 365**: similar; good if you already use Office.
3. **xneelo mail**: usually cheapest and local; fewer admin tools. Confirm alias limits and DKIM support.
Approach: 3 to 4 paid mailboxes (info, bookings, accounts, ron) plus aliases keeps cost low while each brand keeps its own address.
No mailbox credentials appear in the site. The old `info@pulsestream.za` and the Gmail address from the previous site were not carried over.
