# Payment configuration plan

**Status: not built, nothing enabled.** The website shows no banking details and no payment function. No account number is stored anywhere in this project.

## Principles
- Banking details live only in Vercel environment variables (see `.env.example`), never in HTML, JS, JSON or Git.
- EFT instructions are sent in the **quotation/invoice email** with a unique reference. Public pages say only "banking details provided with your quotation".
- Nothing is marked "paid", and no confirmations are generated.

## Commercial payments
Reference format: `PSM-<YYYYMM>-<number>` (e.g. quote/invoice number). Track in `docs/templates/commercial-ledger.csv` (move to a spreadsheet or accounting tool).
Covers: bookings, deposits, balances and invoices for photography, video, podcast, recording and corporate work.

## Charitable contributions (separate)
Reference format: `VAC-<CAMPAIGN>-<number>`. Separate ledger (`charity-ledger.csv`) and separate reporting; never combined with commercial income.
The charity is an initiative with no separate legal status or bank account claimed. Confirm with your accountant how contributions are to be held and reported
before publishing any account details. No tax-deductibility is claimed anywhere.

## Future options (each needs your approval)
1. A private payment-instructions page protected by a signed, expiring link (needs a small Vercel serverless function + `PAYMENT_LINK_SECRET`).
2. A payment gateway (for example PayFast or Yoco): the owner creates the merchant account; keys go in environment variables only.
3. A booking system with deposits.
