# SEO implementation report

## Checklist status (what the code does; verified items are marked)
| # | Item | Status |
|---|---|---|
| 1 | Remove noindex | No noindex was found in the old page. All 18 content pages are `index,follow`; only the 404 and coming-soon pages carry noindex on purpose. Verified by script. |
| 2-3 | Unique titles and descriptions | Done on all 20 pages, titles 62 characters or fewer, descriptions 70 to 165. Verified by script. |
| 4 | Alt text | Every image has an alt attribute; photos have descriptive alt with no personal names. Logos beside brand names use empty alt on purpose. Verified. |
| 5 | Canonical tags | Self-referencing absolute canonical per page on its own host. Verified. |
| 6, 12 | One H1, correct hierarchy | One H1 per page, no skipped levels. Verified. |
| 7 | Core Web Vitals | Measured locally (Chromium, no throttling): CLS 0 on four sampled pages, LCP 128 to 212 ms, first screen about 50 to 93 KB excluding Google Fonts. **Not a production measurement.** |
| 8 | Image compression | 86 MB of originals became 7.6 MB across all AVIF/WebP sizes. |
| 9 | Mobile | Tested at 390, 820 and 1440 px in Chromium: no horizontal overflow, no broken images. |
| 10 | HTTPS | Not testable until deployed. `vercel.json` adds HSTS; Vercel issues certificates. |
| 11, 13 | Broken links, internal linking | 937 links checked, 0 broken (internal and cross-host, including anchors). Brands cross-link in the footer and brand cards. |
| 14 | Slugs | /about, /services, /pricing, /portfolio, /podcast-studio, /videography, /pa-events, /faq, /contact, /privacy, /terms. |
| 15-16 | sitemap.xml, robots.txt | One pair per host, served by host rewrite; contents verified for all 7 hosts. |
| 17 | OG images | 1200x630 per brand plus Open Graph and Twitter tags. Preview rendering on Facebook, LinkedIn and WhatsApp has **not** been tested (needs live URLs). |
| 18 | Backlink strategy | See below. |
| 19 | Schema | JSON-LD: Organization, WebSite, ProfessionalService with address and hours, PodcastSeries (two), Person, Service, FAQPage, BreadcrumbList. JSON validity checked; Google's Rich Results Test not run. No ratings or reviews. |
| 20 | Search Console | Not verified. After deployment add the property, add the TXT record Google gives you at xneelo, then submit each host's sitemap. |

## Target keywords (used naturally in titles, headings and copy)
Main: multimedia production company South Africa, photography and videography Gauteng, corporate media production.
OPTIC1: corporate photography, professional portraits, lifestyle photography, event photography.
TVA: Zimbabwean diaspora podcast. Studio page: podcast recording studio, podcast production, video podcast, mobile podcast.
TOPS: African feminine podcast, African women's conversations. Ron: web design and development, website developer.
Charity: community empowerment, community development. Recording: music recording studio, vocal recording, mixing and mastering.

## Backlink strategy (legitimate only)
1. Google Business Profile for the Germiston address (verification required). Add to Bing Places and Apple Business Connect.
2. South African business directories: check the current terms of listings such as Yellow Pages South Africa, Hotfrog and Cylex before submitting; use identical name, address and phone everywhere.
3. Podcast directories (Spotify, Apple Podcasts, YouTube, Podcast Index) for The Voice Amplified and Thoughts and Other Problems, linking to their pages.
4. Real clients and partners (for example event organisers you have photographed) linking to your work, with their permission.
5. Local chambers of commerce, creative-industry bodies, and guest articles or interviews. No bought links, link farms or comment spam.
