from render import *

TODAY = "2026-11-16"
NAV_MAIN = [("About", "/about/"), ("Services", "/services/"), ("Pricing", "/pricing/"), ("Portfolio", "/portfolio/"),
            ("Podcast studio", "/podcast-studio/"), ("Brands", "/#brands")]
CTA_MAIN = ("Book now", "/contact/")


def sec(id_, title, inner, intro="", alt=False, cls=""):
    return (f'<section class="section{" section--alt" if alt else ""} {cls}" id="{id_}" aria-labelledby="{id_}-h"><div class="wrap">'
            f'<div class="section-head"><h2 id="{id_}-h">{title}</h2>{f"<p>{intro}</p>" if intro else ""}</div>{inner}</div></section>')


def card(title, text, href=None, more="Learn more"):
    return (f'<article class="card"><h3>{title}</h3><p>{text}</p>' + (f'<a class="more" href="{href}">{more} &rarr;</a>' if href else "") + "</article>")


def price_block(title, rows):
    return (f'<div class="price-block"><h3>{title}</h3>' +
            "".join(f'<div class="price-row"><span>{a}</span><b>From {b}</b></div>' for a, b in rows) + "</div>")


def packages(sel=None, href="/contact/"):
    out = ""
    for name, price, items, _ in PACKAGES:
        if sel and name not in sel:
            continue
        out += (f'<article class="card pkg"><h3>{name}</h3><div class="price">From {price}</div><ul>' +
                "".join(f"<li>{i}</li>" for i in items) + f'</ul><a class="btn" href="{href}" style="margin-top:auto">Request this package</a></article>')
    return out


def gallery(keys, gid, cols=4):
    cats = []
    for k in keys:
        c = IMG[k]["category"]
        if c not in cats:
            cats.append(c)
    fl = '<button type="button" data-filter="all" aria-pressed="true">All</button>' + "".join(
        f'<button type="button" data-filter="{c}" aria-pressed="false">{c}</button>' for c in cats)
    figs = ""
    for k in keys:
        m = IMG[k]
        figs += (f'<figure data-cat="{m["category"]}"><button type="button" data-full="/assets/images/{k}-1600.webp" data-alt="{e(m["alt"])}" '
                 f'aria-label="View larger: {e(m["alt"])}">{picture(k, sizes="(max-width:620px) 46vw, 25vw", widths=[480, 800], default_w=480)}</button>'
                 f'<figcaption>{m["category"]}</figcaption></figure>')
    return f'<div class="filters" data-filters="{gid}" role="group" aria-label="Filter portfolio">{fl}</div><div class="gallery" id="{gid}" style="--cols:{cols}">{figs}</div>'


MAIN_PORT = ["corporate-portrait-grey-coat", "lifestyle-street-white-suit", "family-studio-group-portrait",
             "corporate-headshot-navy-blazer-arms-crossed", "event-golf-day-gazebo-group-a", "group-portrait-three-girls",
             "portrait-black-vest-grey-backdrop", "family-group-portrait-brown-backdrop"]


def org_ld():
    return {"@context": "https://schema.org", "@type": "Organization", "@id": "https://pulsestream.africa/#org",
            "name": "Pulse Stream Media", "url": "https://pulsestream.africa/",
            "logo": "https://pulsestream.africa/assets/brand/pulsestream-logo.png",
            "description": "South African multimedia production company: photography, videography, podcast production, music recording and event audio.",
            "telephone": "+27621834708", "email": "info@pulsestream.africa",
            "address": {"@type": "PostalAddress", "streetAddress": "10 Morgan Road, Webber", "addressLocality": "Germiston",
                        "addressRegion": "Gauteng", "addressCountry": "ZA"},
            "sameAs": [l for v in SOCIALS.values() for _, l in v]}


def local_ld(brand, name, desc, path="/", cats=None):
    return {"@context": "https://schema.org", "@type": "ProfessionalService", "@id": url(brand, "/#business"), "name": name,
            "url": url(brand, path), "description": desc, "telephone": "+27621834708",
            "email": BRANDS[brand]["contact_email"], "image": f"https://{HOSTS[brand]}/assets/brand/og-{brand}.jpg",
            "parentOrganization": {"@id": "https://pulsestream.africa/#org"},
            "address": {"@type": "PostalAddress", "streetAddress": "10 Morgan Road, Webber", "addressLocality": "Germiston",
                        "addressRegion": "Gauteng", "addressCountry": "ZA"},
            "areaServed": {"@type": "AdministrativeArea", "name": "Gauteng"},
            "openingHoursSpecification": [{"@type": "OpeningHoursSpecification", "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                                           "opens": "05:00", "closes": "21:00"}]}


def contact_block(brand, services=None, fid="enquiry", title="Start a project", intro="Tell us what you are planning and we will prepare a quotation."):
    b = BRANDS[brand]
    mails = "".join(f'<li><span>Email</span><a href="mailto:{m}">{m}</a></li>' for m in b["emails"])
    addr = f'<li><span>Address</span><b>{ADDRESS_LINE}</b></li>' if b["show_address"] else ""
    info = (f'<ul class="info-list"><li><span>WhatsApp</span><a href="{wa_link()}" rel="noopener">{WA_DISPLAY}</a></li>{mails}{addr}</ul>'
            f'<h3 style="margin-top:1.6rem">Opening hours</h3>{hours_list()}')
    return sec("contact", title, f'<div class="grid split">{enquiry_form(brand, services, fid)}<div>{info}</div></div>', intro, alt=True)


def faq_block(n=None, brand_h="Frequently asked questions"):
    qs = FAQS[:n] if n else FAQS
    return "".join(f"<details><summary>{q}</summary><p>{a}</p></details>" for q, a in qs)


def faq_ld(n=None):
    qs = FAQS[:n] if n else FAQS
    return {"@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in qs]}


def page_hero(h1, lead, eyebrow="", btns=""):
    return (f'<section class="hero hero--center"><div class="wrap"><div>{f"<span class=eyebrow>{eyebrow}</span>" if eyebrow else ""}'
            f'<h1>{h1}</h1><p class="lead">{lead}</p>{btns}</div></div></section>')


def studio_rows():
    return "".join(f'<div class="price-row"><span>{a}</span><b>From {b}</b></div>' for a, b in PRICES["Podcast production and studio rental"])


def build_main():
    P = {}
    P_ = lambda path, title, desc, body, schema=(), crumbs=None, **kw: P.__setitem__(path, dict(
        title=title, desc=desc, body=body, schema=list(schema), crumbs=crumbs, **kw))
    B = BRANDS

    # ---------- Home ----------
    brand_cards = ""
    for k, tag in (("optic1", "Photography"), ("tva", "Podcast"), ("tops", "Podcast"), ("music", "Recording"), ("ron", "Web & creative"), ("charity", "Community initiative")):
        b = B[k]
        desc = {
            "optic1": "Corporate, portrait, family, lifestyle, event and product photography.",
            "tva": "A Zimbabwean diaspora podcast amplifying voices through meaningful conversations.",
            "tops": "A rising African feminine podcast with its own voice and identity.",
            "music": "Vocal recording, beat production, mixing and mastering.",
            "ron": "Web design, web development and digital solutions.",
            "charity": "A community initiative focused on empowerment and social development."}[k]
        mark = (logo_img(k, 56) if b["logo"] else
                f'<span class="bc-mono" style="background:{"#168f89" if k == "ron" else "#c9611f"}">{"RW" if k == "ron" else "VA"}</span>')
        brand_cards += (f'<article class="card brand-card"><div class="bc-top">{mark}<div><h3 style="margin:0">{b["name"]}</h3><span class="tag">{tag}</span></div></div>'
                        f'<div class="bc-body"><p>{desc}</p><a class="more" href="{url(k)}">Visit {b["short"]} &rarr;</a></div></article>')
    services_cards = (
        card("Photography", "Corporate photography, executive portraits, family, lifestyle, event and product photography through OPTIC1 Media.", url("optic1"), "Visit OPTIC1 Media") +
        card("Videography", "Promotional videos, social media reels, business profile videos and event videography.", "/videography/") +
        card("Podcast production and studio", "Studio recording, video podcasts, editing and mobile podcast production.", "/podcast-studio/") +
        card("Music recording", "Vocal recording, beat production, mixing and mastering.", url("music"), "Visit Pulse Stream Recording") +
        card("Events and PA", "PA hire, sound operators, microphones, speakers and event technical support.", "/pa-events/") +
        card("Content creation", "Social media content and brand content for businesses, organisations and creators.", "/services/#content"))
    process = "".join(card(f"{i}. {t}", d) for i, (t, d) in enumerate([
        ("Discover", "We understand your idea, audience and objectives."),
        ("Plan", "We develop the production approach, schedule and requirements."),
        ("Produce", "Our creative and technical team brings the project to life."),
        ("Deliver", "You receive polished, professional media ready for its intended platform.")], 1))
    home = f'''<section class="hero"><div class="wrap"><div><span class="eyebrow">South African multimedia production</span>
<h1>Your story.<br>Our production.</h1>
<p class="lead">Professional multimedia production for businesses, brands, events, organisations and creators across Africa. Photography, video, podcasts, music and event audio under one roof.</p>
<div class="btn-row"><a class="btn" href="/contact/">Start a project</a><a class="btn btn--ghost" href="/portfolio/">View our work</a></div>
<p style="margin-top:1.4rem"><span class="tag">Photography</span><span class="tag">Videography</span><span class="tag">Podcast production</span><span class="tag">Music production</span><span class="tag">Events &amp; PA</span></p></div>
<div class="hero-media">{picture("portrait-black-vest-dark-backdrop", eager=True, sizes="(max-width:980px) 90vw, 500px", widths=[480, 800, 1200], default_w=800)}</div></div></section>
{sec("brands", "One company. Multiple media brands.", f'<div class="grid g3">{brand_cards}</div>', "Each Pulse Stream brand has its own identity, audience and contact channel.", alt=True)}
{sec("services", "Services", f'<div class="grid g3">{services_cards}</div>', "Professional creativity should be accessible. We combine reliable equipment, creative thinking and practical production solutions at competitive prices.")}
{sec("studio", "Podcast studio rental", f'<div class="grid g2" style="gap:3rem"><div><p class="lead">Record an audio or video podcast by the hour, with or without an engineer. Mobile podcast production is also available at your location, subject to availability and travel.</p><div class="btn-row"><a class="btn" href="/podcast-studio/">Studio details and packages</a><a class="btn btn--wa" href="{wa_link("Hello, I would like to book the podcast studio.")}" rel="noopener">Book on WhatsApp</a></div></div><div>{studio_rows()}<p class="price-note">Starting prices. Travel and extras are quoted separately.</p></div></div>', alt=True)}
{sec("about", "We create media with purpose.", f'<p class="lead" style="margin-bottom:2rem">Pulse Stream Media is a South African multimedia company built around the belief that good production is more than equipment. It is about understanding the story, the audience and the objective behind the project.</p><div class="grid g4">{process}</div><div class="btn-row"><a class="btn btn--ghost" href="/about/">More about Pulse Stream</a></div>')}
{sec("work", "Selected photography", gallery(MAIN_PORT, "gallery-home", 4) + '<div class="btn-row"><a class="btn btn--ghost" href="/portfolio/">Full portfolio</a></div>', "Photography by Pulse Stream and OPTIC1 Media.", alt=True)}
{sec("faq", "Frequently asked questions", faq_block(4) + '<p style="margin-top:1.2rem"><a class="more" href="/faq/" style="color:var(--accent);font-weight:600">See all questions &rarr;</a></p>')}
{contact_block("main")}'''
    P_("/", "Pulse Stream Media | Photography, Video & Podcast Production",
       "Pulse Stream Media is a South African multimedia production company in Gauteng: photography, videography, podcast studio rental, music recording and event audio.",
       home, [org_ld(), {"@context": "https://schema.org", "@type": "WebSite", "name": "Pulse Stream Media", "url": "https://pulsestream.africa/", "publisher": {"@id": "https://pulsestream.africa/#org"}},
              local_ld("main", "Pulse Stream Media", "Multimedia production company in Gauteng, South Africa.")])

    # ---------- About ----------
    P_("/about/", "About Pulse Stream Media | Multimedia Company, South Africa",
       "Learn about Pulse Stream Media, a South African multimedia production company with divisions in photography, podcasts, recording and community initiatives.",
       page_hero("About Pulse Stream Media", "More than media. Creative production, technical expertise and storytelling together under one roof.", "About us") +
       sec("story", "Who we are", f'''<div class="prose"><p>Pulse Stream Media is a South African multimedia production company providing creative, technical and professional media services: photography, videography, podcast production, music recording, audio engineering, corporate media, events and multimedia equipment, and digital content creation.</p>
<p>From a corporate executive portrait to a multi-camera event, podcast, music production or branded campaign, every project is approached with professionalism, creativity and attention to detail.</p>
<p>Our promise is simple: professional creativity should be accessible. We combine reliable equipment, creative thinking and practical production solutions to deliver quality multimedia services at competitive prices.</p></div>''') +
       sec("divisions", "Our brands", "".join(f'<article class="card"><h3>{B[k]["name"]}</h3><p>{d}</p><a class="more" href="{url(k)}">Visit &rarr;</a></article>' for k, d in (
           ("optic1", "Our photography brand."), ("tva", "A Zimbabwean diaspora podcast owned by Pulse Stream."), ("tops", "A rising African feminine podcast."),
           ("music", "Music recording, mixing and mastering."), ("ron", "A personal creative and professional brand within the Pulse Stream ecosystem."),
           ("charity", "A community initiative being developed under Pulse Stream."))).join(['<div class="grid g3">', "</div>"]), alt=True) +
       sec("charity", "Production with a purpose beyond business", f'<p class="lead">Alongside our production work, Pulse Stream is developing The Voice Amplified Charity, a community initiative. It is an initiative, not a registered non-profit organisation, and its funds are kept separate from our commercial income.</p><div class="btn-row"><a class="btn" href="{url("charity")}">About the charity initiative</a></div>'),
       crumbs=[("Home", "/"), ("About", "/about/")])

    # ---------- Services hub ----------
    def svc(id_, title, items, link=None, label=""):
        lst = "".join(f"<li>{i}</li>" for i in items)
        return sec(id_, title, f'<div class="prose"><ul>{lst}</ul></div>' + (f'<div class="btn-row"><a class="btn btn--ghost" href="{link}">{label}</a></div>' if link else ""), alt=id_ in ("videography", "music", "content"))
    P_("/services/", "Multimedia Services in Gauteng | Pulse Stream Media",
       "Photography, videography, podcast production, music recording, event PA and content creation from Pulse Stream Media in Gauteng, South Africa.",
       page_hero("Our multimedia services", "One production partner means fewer moving parts and a smoother production process.", "Services") +
       svc("photography", "Photography", ["Corporate photography and executive portraits", "Professional portraits", "Family and lifestyle photography", "Event photography", "Commercial and product photography", "Professional photo editing"], url("optic1"), "Visit OPTIC1 Media") +
       svc("videography", "Videography", ["Short promotional videos", "Social media videos and reels", "Business profile and company videos", "Event videography", "Music video production", "Video editing"], "/videography/", "Videography details and prices") +
       svc("podcast", "Podcast production", ["Podcast studio recording", "Video podcast production", "Interviews", "Mobile podcast production", "Corporate podcast production", "Podcast marketing and content distribution"], "/podcast-studio/", "Podcast studio and prices") +
       svc("music", "Music recording and production", ["Vocal recording", "Beat production", "Mixing and mastering", "Full song production"], url("music"), "Visit Pulse Stream Recording") +
       svc("events", "Events and PA", ["PA systems with or without a sound operator", "Microphone and speaker hire", "Small event sound packages", "Event technical support", "Conferences, product launches and brand activations"], "/pa-events/", "PA and events details") +
       svc("content", "Content creation", ["Social media content", "Brand and business introduction content", "Internal communications media"]),
       [org_ld()], [("Home", "/"), ("Services", "/services/")])

    def service_page(path, title, desc, h1, lead, key, crumb):
        P_(path, title, desc,
           page_hero(h1, lead, "Services") + sec("prices", "Starting prices", price_block(key, PRICES[key]) + f'<p class="price-note">{PRICE_NOTE}</p>', alt=True) +
           sec("faq", "Common questions", faq_block(4)) + contact_block("main", fid="enquiry-" + path.strip("/")),
           [org_ld(), faq_ld(4)], [("Home", "/"), ("Services", "/services/"), (crumb, path)], book_href="#contact")
    service_page("/videography/", "Videography in Gauteng | Pulse Stream Media",
                 "Promotional videos, social media reels, business profile videos, event videography and music videos in Gauteng from Pulse Stream Media.",
                 "Videography and content creation", "Professional video production for businesses, brands, events and artists.", "Videography and content creation", "Videography")
    service_page("/pa-events/", "PA Hire & Event Audio | Pulse Stream Media",
                 "PA system hire, sound operators, microphones, speakers and event technical support from Pulse Stream Media in Gauteng.",
                 "PA systems and event equipment", "Reliable sound and technical support for events. Equipment availability, delivery, setup, transport and duration affect the final quotation.", "PA systems and event equipment", "PA and events")

    P_("/podcast-studio/", "Podcast Studio Rental & Production | Pulse Stream",
       "Hire a podcast studio in Gauteng by the hour, with or without an engineer. Audio and video podcast recording, editing and social clips from Pulse Stream.",
       page_hero("Podcast studio rental and production", "Record an audio or video podcast by the hour, with or without an engineer, or let us come to you.", "Podcast studio",
                 f'<div class="btn-row"><a class="btn" href="#contact">Book the studio</a><a class="btn btn--wa" href="{wa_link("Hello, I would like to book the podcast studio.")}" rel="noopener">WhatsApp us</a></div>') +
       sec("rates", "Studio rates and production", price_block("Podcast production and studio rental", PRICES["Podcast production and studio rental"]) + f'<p class="price-note">{PRICE_NOTE}</p>') +
       sec("package", "Podcast Starter Package", f'<div class="grid g3">{packages(["Podcast Starter Package"])}</div>', alt=True) +
       sec("services", "What we can produce", '<div class="prose"><ul><li>Studio recording and video podcast production</li><li>Interviews and corporate podcast production</li><li>Mobile podcast production at your location</li><li>Podcast marketing and content distribution</li></ul></div>') +
       sec("faq", "Common questions", faq_block(4), alt=True) + contact_block("main", ["Podcast studio rental", "Podcast production", "Other"], "enquiry-studio", "Book the podcast studio"),
       [org_ld(), faq_ld(4), {"@context": "https://schema.org", "@type": "Service", "name": "Podcast studio rental and production", "provider": {"@id": "https://pulsestream.africa/#org"},
                              "areaServed": "Gauteng, South Africa"}], [("Home", "/"), ("Podcast studio", "/podcast-studio/")], book_href="#contact")

    # ---------- Pricing ----------
    P_("/pricing/", "Pricing | Photography, Video, Podcast & Music | Pulse Stream",
       "Starting prices for photography, videography, podcast studio hire, music production and PA equipment from Pulse Stream Media. Prices in South African rand.",
       page_hero("Pricing", "Accessible starting prices for clients who are just getting started. Every project is confirmed in a written quotation.", "Pricing") +
       sec("rates", "Starting prices", "".join(price_block(k, v) for k, v in PRICES.items()) + f'<p class="price-note">{PRICE_NOTE}</p>') +
       sec("packages", "Introductory packages", f'<div class="grid g3">{packages()}</div>', "Introductory packages designed to make it easier to book more than one service. Limits on revisions, travel, editing time and delivery periods are defined in your quotation.", alt=True) +
       contact_block("main", fid="enquiry-pricing", title="Request a quotation"),
       [org_ld()], [("Home", "/"), ("Pricing", "/pricing/")])

    P_("/portfolio/", "Photography Portfolio | Pulse Stream Media",
       "Selected corporate, portrait, family, lifestyle and event photography by Pulse Stream Media and OPTIC1 Media in Gauteng.",
       page_hero("Portfolio", "Selected photography. Filter by category and tap an image to enlarge.", "Our work") +
       sec("gallery", "Photography", gallery(MAIN_PORT, "gallery-main", 4), alt=True) +
       sec("more", "Want to see more?", f'<p class="lead">OPTIC1 Media, our photography brand, has a larger gallery.</p><div class="btn-row"><a class="btn" href="{url("optic1")}/#portfolio">OPTIC1 Media gallery</a><a class="btn btn--ghost" href="/contact/">Start a project</a></div>'),
       [org_ld()], [("Home", "/"), ("Portfolio", "/portfolio/")])

    P_("/faq/", "FAQ | Bookings, Deposits & Delivery | Pulse Stream Media",
       "Answers to common questions about bookings, deposits, delivery, mobile production and custom quotations at Pulse Stream Media.",
       page_hero("Frequently asked questions", "Everything you need to know before you book.", "FAQ") + sec("questions", "Questions and answers", faq_block(), alt=True),
       [faq_ld()], [("Home", "/"), ("FAQ", "/faq/")])

    P_("/contact/", "Contact & Book | Pulse Stream Media, Germiston",
       "Contact Pulse Stream Media to book photography, video, podcast or music production. WhatsApp, email and enquiry form. Germiston, Gauteng.",
       page_hero("Contact and bookings", "Tell us what you are planning. We will reply with a quotation.", "Contact") + contact_block("main", fid="enquiry-contact", title="Send an enquiry"),
       [org_ld()], [("Home", "/"), ("Contact", "/contact/")], book_href="#contact")

    # ---------- Legal ----------
    P_("/privacy/", "Privacy Notice (POPIA) | Pulse Stream Media",
       "How Pulse Stream Media collects, uses and protects personal information in line with the Protection of Personal Information Act (POPIA).",
       page_hero("Privacy notice", "How we handle personal information under the Protection of Personal Information Act (POPIA).", "Legal") +
       sec("notice", "Your information", '''<div class="prose">
<h3>Who we are</h3><p>The responsible party is Pulse Stream Media, 10 Morgan Road, Webber, Germiston. Contact: <a href="mailto:info@pulsestream.africa">info@pulsestream.africa</a>.</p>
<h3>What we collect</h3><p>Only what you choose to send us through an enquiry: your name, email address, phone number, optional company name, service, preferred date, budget range and project description.</p>
<h3>How it reaches us</h3><p>Our enquiry forms do not store data on our website. They open your email app or WhatsApp with your message prepared. What you send is then received by us through email or WhatsApp.</p>
<h3>Why we use it</h3><p>To respond to your enquiry, prepare quotations, deliver the services you request and keep business records. We do not sell your information.</p>
<h3>Your rights</h3><p>You may ask us to access, correct or delete your personal information, or object to its use, by emailing us. You may also contact the Information Regulator of South Africa.</p>
<h3>Third-party services</h3><p>Fonts are loaded from Google Fonts. Links to WhatsApp, Facebook and YouTube are governed by those services&rsquo; own privacy policies.</p></div>'''),
       [], [("Home", "/"), ("Privacy notice", "/privacy/")], follow=False)
    P_("/terms/", "Terms & Conditions | Pulse Stream Media",
       "General terms for bookings, quotations, deposits and delivery with Pulse Stream Media.",
       page_hero("Terms and conditions", "General terms. Your written quotation sets out the specific terms for your project.", "Legal") +
       sec("terms", "General terms", '''<div class="prose"><ul>
<li><b>Quotations.</b> Prices on this website are &ldquo;starting from&rdquo; rates, not guaranteed all-inclusive prices. Each project is confirmed in a written quotation.</li>
<li><b>Deposits.</b> A booking deposit is required to secure production dates. The amount is confirmed in your quotation.</li>
<li><b>Travel and extras.</b> Travel, additional editing, special requirements, licensing and additional deliverables are quoted separately.</li>
<li><b>Delivery.</b> Estimated delivery dates are provided when your booking is confirmed.</li>
<li><b>VAT.</b> Pulse Stream is not currently VAT-registered.</li>
<li><b>Equipment.</b> Equipment availability, delivery, setup, transport and event duration affect final quotations.</li></ul>
<p>The quotation you accept forms the agreement for your project.</p></div>'''),
       [], [("Home", "/"), ("Terms", "/terms/")], follow=False)

    # ---------- Special ----------
    P_("/coming-soon/", "Coming soon | Pulse Stream Media", "A new Pulse Stream service is on its way. Message us on WhatsApp or email to hear when it launches.",
       '<section class="center-page"><div class="wrap"><span class="eyebrow">Coming soon</span><h1>A new project is coming</h1><p class="lead" style="margin-inline:auto">We are preparing something new. Message us on WhatsApp or by email and we will let you know when it launches.</p>'
       f'<div class="btn-row" style="justify-content:center"><a class="btn btn--wa" href="{wa_link()}" rel="noopener">WhatsApp us</a><a class="btn btn--ghost" href="/">Back to home</a></div></div></section>',
       robots="noindex,follow", follow=False)
    P_("/404.html", "Page not found | Pulse Stream Media", "The page you are looking for could not be found. Return to the Pulse Stream Media home page or contact us.",
       '<section class="center-page"><div class="wrap"><div class="big-num" aria-hidden="true">404</div><h1 style="font-size:2rem">Page not found</h1><p class="lead" style="margin-inline:auto">The page may have moved or never existed.</p>'
       '<div class="btn-row" style="justify-content:center"><a class="btn" href="/">Return home</a><a class="btn btn--ghost" href="/contact/">Contact us</a></div></div></section>',
       robots="noindex,follow", follow=False)
    return P
