"""All business data lives here. Nothing is invented: every value came from the owner.
Banking details are deliberately NOT in this repository (see docs/payments-plan.md)."""

WA_NUMBER = "27621834708"
WA_DISPLAY = "+27 62 183 4708"
ADDRESS_LINE = "10 Morgan Road, Webber, Germiston"
HOURS = [
    ("Monday to Friday", "05:00 – 21:00"),
    ("Saturday and Sunday", "By appointment only"),
    ("Public holidays", "05:00 – 17:00"),
]

HOSTS = {
    "main": "pulsestream.africa",
    "optic1": "optic1.pulsestream.africa",
    "tva": "tva.pulsestream.africa",
    "tops": "tops.pulsestream.africa",
    "ron": "ron.pulsestream.africa",
    "charity": "charity.pulsestream.africa",
    "music": "music.pulsestream.africa",
}

# Supplied by the owner. Brands not listed here have no social links yet.
SOCIALS = {
    "tva": [("Facebook", "https://www.facebook.com/thevoiceamplifiedpodcast"),
            ("YouTube", "https://www.youtube.com/@thevoiceamplifiedpodcast")],
    "tops": [("Facebook", "https://www.facebook.com/profile.php?id=61596595641580")],
    "ron": [("Facebook", "https://www.facebook.com/casathedj/")],
}

BRANDS = {
    "main": dict(name="Pulse Stream Media", short="Pulse Stream", sub="Multimedia production",
                 logo="pulsestream", fav="main", show_address=True,
                 emails=["info@pulsestream.africa", "bookings@pulsestream.africa", "accounts@pulsestream.africa"],
                 contact_email="bookings@pulsestream.africa"),
    "optic1": dict(name="OPTIC1 Media", short="OPTIC1", sub="by Pulse Stream", logo="optic1", fav="optic1",
                   show_address=True, emails=["optic1@pulsestream.africa"], contact_email="optic1@pulsestream.africa"),
    "tva": dict(name="The Voice Amplified Podcast", short="The Voice Amplified", sub="Podcast", logo="tva", fav="tva",
                show_address=False, emails=["voiceamplified@pulsestream.africa", "partnerships@pulsestream.africa"],
                contact_email="voiceamplified@pulsestream.africa"),
    "tops": dict(name="Thoughts and Other Problems", short="Thoughts and Other Problems", sub="Podcast", logo="tops",
                 fav="tops", show_address=False, emails=["thoughts@pulsestream.africa"],
                 contact_email="thoughts@pulsestream.africa"),
    "ron": dict(name="Ron Wayez", short="Ron Wayez", sub="Web & creative", logo=None, fav="ron", show_address=False,
                emails=["ron@pulsestream.africa"], contact_email="ron@pulsestream.africa"),
    "charity": dict(name="The Voice Amplified Charity", short="The Voice Amplified Charity", sub="A Pulse Stream initiative",
                    logo=None, fav="charity", show_address=False,
                    emails=["charity@pulsestream.africa", "donations@pulsestream.africa"],
                    contact_email="charity@pulsestream.africa"),
    "music": dict(name="Pulse Stream Recording", short="Pulse Stream Recording", sub="Music studio", logo="pulsestream",
                  fav="music", show_address=True, emails=["recording@pulsestream.africa"],
                  contact_email="recording@pulsestream.africa"),
}

# Prices: introductory "starting from" rates approved by the owner (ZAR). Not VAT registered.
PRICES = {
    "Photography": [
        ("Individual portraits", "R450"), ("Professional headshots", "R550"), ("Family photoshoot", "R850"),
        ("Lifestyle photoshoot", "R750"), ("Couple photoshoot", "R750"), ("Corporate photography", "R1,500"),
        ("Event photography (2 hours)", "R2,000"), ("Product photography", "R650")],
    "Videography and content creation": [
        ("Short promotional video", "R1,200"), ("Social media video / Reel", "R500"), ("Business profile video", "R2,000"),
        ("Event videography (2 hours)", "R2,500"), ("Music video production", "R3,500"), ("Video editing", "R350/hour")],
    "Podcast production and studio rental": [
        ("Audio-only studio recording", "R350/hour"), ("Audio recording with engineer", "R550/hour"),
        ("Video podcast recording", "R850/hour"), ("Basic audio editing", "R350/episode"),
        ("Video podcast editing", "R750/episode"), ("Social media clips", "R200 each"),
        ("Podcast intro/outro production", "R650")],
    "Music production": [
        ("Vocal recording", "R250/hour"), ("Basic vocal editing", "R350"), ("Beat production", "R800"),
        ("Song mixing", "R750"), ("Song mastering", "R350"), ("Full song production", "R1,800")],
    "PA systems and event equipment": [
        ("Basic PA hire", "R800/day"), ("PA with sound operator", "R1,500/day"), ("Microphone hire", "R150/day"),
        ("Speaker hire", "R350/day"), ("Small event sound package", "R1,800"), ("Event technical support", "R750")],
}
PRICE_NOTE = ("All prices are in South African rand and shown as “starting from”. Pulse Stream is not currently "
              "VAT-registered. Travel, extra editing, deposits, licensing and special requirements are stated in your quotation.")

PACKAGES = [
    ("Personal Starter Package", "R950", ["1-hour photoshoot", "10 edited photographs", "Digital delivery", "One location"], "optic1"),
    ("Business Visibility Package", "R2,500", ["10 business photographs", "2 promotional social media videos",
                                                "Basic business introduction content", "Digital delivery"], "main"),
    ("Podcast Starter Package", "R1,500", ["Up to 2 hours recording", "Audio and video capture", "Basic episode edit",
                                           "2 social media clips"], "main"),
    ("Event Essentials Package", "R3,500", ["2 hours event coverage", "Event photography", "Short highlight video",
                                            "Edited digital deliverables"], "main"),
]

FAQS = [
    ("Do you offer services outside your studio?",
     "Yes. Pulse Stream provides mobile multimedia production services at client locations, subject to availability and travel arrangements."),
    ("Can I book more than one service?",
     "Yes. Photography, videography, podcast production, music production and event technical services can be combined into customised packages."),
    ("Do I need to pay a deposit?",
     "A booking deposit is required to secure production dates. The amount will be confirmed in your quotation."),
    ("How long does delivery take?",
     "Delivery depends on the nature and size of the project. Your estimated delivery date will be provided when your booking is confirmed."),
    ("Can I request a customised quotation?",
     "Absolutely. Send us your requirements and we will prepare a quotation according to your project scope and budget."),
    ("Do you work with companies and organisations?",
     "Yes. We work with individuals, SMEs, corporate clients, organisations, artists and event organisers."),
    ("Can I use my own equipment?",
     "Yes, depending on the project. We can discuss equipment-only hire or production support where available."),
]

SERVICE_OPTIONS = ["Photography", "Videography", "Podcast production", "Podcast studio rental", "Music recording",
                   "Event production", "PA / audio hire", "Content creation", "Other"]
BUDGETS = ["Not sure yet", "Under R2,000", "R2,000 – R10,000", "R10,000 – R30,000", "R30,000+"]
