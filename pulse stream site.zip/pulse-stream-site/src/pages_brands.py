from pages_main import *

OPTIC1_PORT = ["corporate-portrait-grey-coat", "lifestyle-street-white-suit", "family-studio-group-portrait", "group-portrait-three-girls",
               "corporate-headshot-navy-blazer-arms-crossed", "portrait-black-vest-dark-backdrop", "portrait-black-vest-grey-backdrop",
               "event-golf-day-gazebo-group-a", "event-golf-day-gazebo-group-b", "family-group-portrait-brown-backdrop"]


def logo_tag(key, w, eager=True):
    W, H = IMG["_logos"][key]
    return f'<img src="/assets/brand/{key}-logo.webp" width="{w}" height="{round(w * H / W)}" alt="{e(BRANDS[key if key in BRANDS else "main"]["name"])} logo" {"fetchpriority=high" if eager else "loading=lazy"}>'


def simple_nav(items, cta):
    return items, cta


def build_optic1():
    b = "optic1"
    nav = [("Services", "/#services"), ("Pricing", "/#pricing"), ("Portfolio", "/#portfolio"), ("FAQ", "/#faq"), ("Contact", "/#contact")]
    cta = ("Book a shoot", "/#contact")
    desc_map = {"Individual portraits": "Studio or on-location portraits for personal and professional use.",
                "Professional headshots": "Clean, polished headshots for LinkedIn, websites and company profiles.",
                "Family photoshoot": "Relaxed family portraits in the studio or at a location of your choice.",
                "Lifestyle photoshoot": "Natural, story-led photography of you in your own setting.",
                "Couple photoshoot": "Portraits and candid moments for couples.",
                "Corporate photography": "Team, executive and workplace photography for organisations.",
                "Event photography (2 hours)": "Coverage of corporate and private events, with edited images delivered digitally.",
                "Product photography": "Clear product images for catalogues, online stores and social media."}
    svc = "".join(f'<article class="card"><h3>{n}</h3><p>{desc_map[n]}</p><b style="color:var(--accent)">From {p}</b></article>' for n, p in PRICES["Photography"])
    pk = f'<div class="grid g3">{packages(["Personal Starter Package", "Business Visibility Package", "Event Essentials Package"], "#contact")}</div>'
    body = f'''<section class="hero"><div class="wrap"><div>{logo_tag("optic1", 200)}<span class="eyebrow" style="margin-top:1.2rem">Photography by Pulse Stream</span>
<h1>Professional photography in Gauteng.</h1>
<p class="lead">OPTIC1 Media creates corporate, portrait, family, lifestyle, event and product photography, with professional photo editing available.</p>
<div class="btn-row"><a class="btn" href="#contact">Book a shoot</a><a class="btn btn--ghost" href="#portfolio">See the portfolio</a></div></div>
<div class="hero-media">{picture("corporate-headshot-navy-blazer-pose", eager=True, sizes="(max-width:980px) 90vw, 500px", widths=[480, 800, 1200], default_w=800)}</div></div></section>
{sec("services", "Photography services", f'<div class="grid g4">{svc}</div>', "Starting prices. Travel and special requirements are quoted separately.", alt=True)}
{sec("pricing", "Introductory packages", pk, f"{PRICE_NOTE}")}
{sec("portfolio", "Portfolio", gallery(OPTIC1_PORT, "gallery-optic1", 5), "Corporate, portrait, family, lifestyle and event photography. Tap an image to enlarge.", alt=True)}
{sec("faq", "Frequently asked questions", faq_block(5))}
{contact_block(b, ["Individual portrait", "Professional headshot", "Family photoshoot", "Lifestyle photoshoot", "Couple photoshoot", "Corporate photography", "Event photography", "Product photography", "Photo editing", "Other"], "enquiry-optic1", "Book a shoot", "Tell us what you need and we will reply with a quotation.")}'''
    return {"/": dict(title="OPTIC1 Media | Photographer in Gauteng, Portraits & Events",
            desc="OPTIC1 Media is a Pulse Stream photography brand in Gauteng: corporate, portrait, family, lifestyle, event and product photography.",
            body=body, schema=[local_ld(b, "OPTIC1 Media", "Photography brand of Pulse Stream Media in Gauteng, South Africa."), faq_ld(5)], crumbs=None, nav=nav, cta=cta, book_href="#contact")}


def build_tva():
    b = "tva"
    nav = [("About", "/#about"), ("Watch & listen", "/#listen"), ("Production", "/#production"), ("Partnerships", "/#partnerships"), ("Contact", "/#contact")]
    cta = ("Get in touch", "/#contact")
    fb, yt = SOCIALS["tva"][0][1], SOCIALS["tva"][1][1]
    body = f'''<section class="hero hero--center"><div class="wrap"><div>{logo_tag("tva", 320)}
<span class="eyebrow" style="margin-top:1.5rem">A Zimbabwean diaspora podcast</span>
<h1>The Voice Amplified Podcast</h1><p class="lead">Amplifying Voices. Inspiring Change. Connecting Communities.</p>
<div class="btn-row" style="justify-content:center"><a class="btn" href="{yt}" target="_blank" rel="noopener noreferrer">Subscribe on YouTube</a><a class="btn btn--ghost" href="{fb}" target="_blank" rel="noopener noreferrer">Follow on Facebook</a></div></div></div></section>
{sec("about", "Our mission", '<div class="prose"><p class="lead">The Voice Amplified Podcast is a Zimbabwean diaspora podcast owned by Pulse Stream Media. Its mission is to amplify the voices of the masses while empowering society through meaningful conversations.</p><p>We speak with people who have achieved success or are in a better position to share knowledge, innovation and ideas, so that communities at home and abroad can learn from them.</p></div>', alt=True)}
{sec("listen", "Watch and listen", f'<div class="grid g2"><article class="card"><h3>Watch on YouTube</h3><p>Full conversations and video content on our YouTube channel.</p><a class="more" href="{yt}" target="_blank" rel="noopener noreferrer">Open the channel &rarr;</a></article><article class="card"><h3>Join us on Facebook</h3><p>Updates, clips and community conversation on our Facebook page.</p><a class="more" href="{fb}" target="_blank" rel="noopener noreferrer">Open the page &rarr;</a></article></div>')}
{sec("hosts", "Hosts and guests", '<div class="notice"><strong>Host and guest profiles are being prepared.</strong> Follow our channels to meet the people behind the conversations. Interested in being a guest? Use the form below.</div>', alt=True)}
{sec("production", "Podcast production for you", f'<div class="grid g3">{card("Studio recording", "Podcast studio recording and video podcast production.", url("main", "/podcast-studio/"), "Studio details")}{card("Mobile production", "Podcast recording at your location, subject to availability.", url("main", "/podcast-studio/"), "Learn more")}{card("Corporate podcasts", "Podcast production, marketing and content distribution for organisations.", url("main", "/services/#podcast"), "Our services")}</div>', "Pulse Stream Media produces podcasts for other creators and organisations.")}
{sec("partnerships", "Partnerships and sponsorship", f'<p class="lead">We work with media partners, sponsors and organisations that share our mission to inspire change and connect communities.</p><div class="btn-row"><a class="btn" href="mailto:partnerships@pulsestream.africa">partnerships@pulsestream.africa</a></div>', alt=True)}
{contact_block(b, ["Be a guest", "Sponsorship or partnership", "Podcast production enquiry", "Media enquiry", "Other"], "enquiry-tva", "Contact the podcast", "Guest requests, partnerships and general enquiries are all welcome.")}'''
    ld = {"@context": "https://schema.org", "@type": "PodcastSeries", "name": "The Voice Amplified Podcast", "url": url(b),
          "description": "A Zimbabwean diaspora podcast amplifying voices through meaningful conversations.",
          "publisher": {"@id": "https://pulsestream.africa/#org"}, "sameAs": [fb, yt]}
    return {"/": dict(title="The Voice Amplified Podcast | Zimbabwean Diaspora Podcast",
            desc="The Voice Amplified Podcast: a Zimbabwean diaspora podcast amplifying voices through meaningful conversations. Watch, subscribe and partner with us.",
            body=body, schema=[ld], crumbs=None, nav=nav, cta=cta, book_href="#contact")}


def build_tops():
    b = "tops"
    nav = [("Introduction", "/#about"), ("Voices", "/#voices"), ("Episodes", "/#episodes"), ("Collaborate", "/#collaborate"), ("Contact", "/#contact")]
    cta = ("Say hello", "/#contact")
    fb = SOCIALS["tops"][0][1]
    body = f'''<section class="hero hero--center"><div class="wrap"><div>{logo_tag("tops", 300)}
<span class="eyebrow" style="margin-top:1.4rem">A rising African feminine podcast</span>
<h1>Thoughts and Other Problems</h1><p class="lead">An African feminine podcast from the Pulse Stream Media family.</p>
<div class="btn-row" style="justify-content:center"><a class="btn" href="{fb}" target="_blank" rel="noopener noreferrer">Follow on Facebook</a><a class="btn btn--ghost" href="#collaborate">Collaborate with us</a></div></div></div></section>
{sec("about", "The podcast", '<div class="prose"><p class="lead">Thoughts and Other Problems is a rising African feminine podcast and part of the Pulse Stream Media family. It has its own voice, its own look and its own conversations.</p><p>African women&rsquo;s conversations deserve a place of their own. This is that place.</p></div>', cls="section--cream")}
{sec("voices", "Presenters and contributors", '<div class="notice"><strong>Introductions are coming.</strong> Presenter and contributor profiles will be shared here once they are ready. Follow our Facebook page to meet the voices first.</div>')}
{sec("episodes", "Episodes: watch and listen", f'<p class="lead">New episodes and video clips are shared on our Facebook page. A full episode archive with audio and video players will appear here as it is published.</p><div class="btn-row"><a class="btn" href="{fb}" target="_blank" rel="noopener noreferrer">Watch on Facebook</a></div>', cls="section--cream")}
{sec("collaborate", "Collaborations and sponsorship", '<div class="grid g2">' + card("Collaborate", "Want to be part of the conversation, as a guest or a creative partner? Tell us who you are and what you have in mind.") + card("Sponsors and partners", "Brands that want to support African women&rsquo;s voices are welcome to enquire about sponsorship.") + '</div>', "Write to <a href=\"mailto:thoughts@pulsestream.africa\" style=\"color:var(--accent)\">thoughts@pulsestream.africa</a> or use the form below.")}
{contact_block(b, ["Be a guest", "Collaboration", "Sponsorship", "General message"], "enquiry-tops", "Get in touch", "We would love to hear from you.")}'''
    ld = {"@context": "https://schema.org", "@type": "PodcastSeries", "name": "Thoughts and Other Problems", "url": url(b),
          "description": "A rising African feminine podcast from Pulse Stream Media.", "publisher": {"@id": "https://pulsestream.africa/#org"}, "sameAs": [fb]}
    return {"/": dict(title="Thoughts and Other Problems | African Feminine Podcast",
            desc="Thoughts and Other Problems is a rising African feminine podcast, with African women's conversations. Follow, collaborate or sponsor.",
            body=body, schema=[ld], crumbs=None, nav=nav, cta=cta, book_href="#contact", font="tops")}


def build_ron():
    b = "ron"
    nav = [("Profile", "/#profile"), ("Skills", "/#skills"), ("Projects", "/#projects"), ("Contact", "/#contact")]
    cta = ("Let's talk", "/#contact")
    fb = SOCIALS["ron"][0][1]
    skills = "".join(card(t, d) for t, d in (
        ("Web design", "Clear, professional website design with a focus on brand and usability."),
        ("Web development", "Responsive, fast, search-friendly websites."),
        ("Digital solutions", "Practical digital tools and systems for businesses."),
        ("Multimedia production", "Creative media work that supports digital projects."),
        ("Creative direction", "Guiding the look, feel and message of a project."),
        ("Content and media projects", "Content planned and produced for the platforms that matter.")))
    body = f'''<section class="hero"><div class="wrap"><div><span class="eyebrow">Web design, development and creative direction</span>
<h1>Ron Wayez</h1><p class="lead">A creative professional working in web design, web development, digital solutions and multimedia production within the Pulse Stream digital ecosystem.</p>
<div class="btn-row"><a class="btn" href="#projects">Selected projects</a><a class="btn btn--ghost" href="#contact">Work with me</a></div></div>
<div class="card" style="padding:2rem"><span class="eyebrow">Currently</span><h2 style="font-size:1.4rem">Pulse Stream Media digital ecosystem</h2><p>Design and development of the Pulse Stream Media website and its brand destinations.</p><a class="more" href="https://pulsestream.africa/">Visit pulsestream.africa &rarr;</a></div></div></section>
{sec("profile", "Professional profile", '<div class="prose"><p class="lead">I design and build websites and digital solutions, and I work across multimedia and creative direction. My personal professional brand sits within the Pulse Stream ecosystem and stays separate from Pulse Stream&rsquo;s corporate identity.</p></div>', alt=True)}
{sec("skills", "Skills and capabilities", f'<div class="grid g3">{skills}</div>')}
{sec("projects", "Selected projects", f'<div class="grid g2"><article class="card"><h3>Pulse Stream Media website</h3><p>A multi-brand website with shared design system and separate brand destinations.</p><a class="more" href="https://pulsestream.africa/">Visit the website &rarr;</a></article><article class="card"><h3>Pulse Stream brand destinations</h3><p>Landing pages for OPTIC1 Media, The Voice Amplified Podcast, Thoughts and Other Problems, The Voice Amplified Charity and Pulse Stream Recording.</p><a class="more" href="https://pulsestream.africa/#brands">See the brands &rarr;</a></article></div><p class="price-note" style="margin-top:1.2rem">More projects will be added as they are ready to share.</p>', alt=True)}
{contact_block(b, ["Web design", "Web development", "Digital solutions", "Multimedia production", "Creative direction", "Other"], "enquiry-ron", "Contact and collaboration", "Have a website or digital project in mind? Tell me about it.")}'''
    ld = {"@context": "https://schema.org", "@type": "Person", "name": "Ron Wayez", "url": url(b), "email": "ron@pulsestream.africa",
          "description": "Web design, web development, digital solutions, multimedia production and creative direction.",
          "knowsAbout": ["Web design", "Web development", "Digital solutions", "Multimedia production", "Creative direction"], "sameAs": [fb]}
    return {"/": dict(title="Ron Wayez | Web Designer & Developer, Creative Digital",
            desc="Ron Wayez: web design, website development, creative digital solutions and multimedia production. View selected projects and get in touch.",
            body=body, schema=[ld], crumbs=None, nav=nav, cta=cta, book_href="#contact")}


def build_charity():
    b = "charity"
    nav = [("Our focus", "/#focus"), ("Pulse Stream", "/#relationship"), ("Get involved", "/#involved"), ("Giving", "/#giving"), ("Contact", "/#contact")]
    cta = ("Get involved", "/#involved")
    focus = "".join(card(t, d) for t, d in (
        ("Community empowerment", "Supporting people and communities to build skills and confidence."),
        ("Social development", "Initiatives that strengthen the communities around us."),
        ("Educational assistance", "Practical support for learning and education."),
        ("Humanitarian activities", "Help for people in need in society."),
        ("Community support projects", "Locally led projects that respond to real needs.")))
    body = f'''<section class="hero hero--center"><div class="wrap"><div><span class="eyebrow">A Pulse Stream Media community initiative</span>
<h1>The Voice Amplified Charity</h1><p class="lead">Community empowerment and social development, built on the belief that every voice deserves to be heard and supported.</p>
<div class="btn-row" style="justify-content:center"><a class="btn" href="#involved">Get involved</a><a class="btn btn--ghost" href="#giving">How giving works</a></div></div></div></section>
<section class="section" style="padding-top:0"><div class="wrap"><div class="notice"><strong>Our status.</strong> The Voice Amplified Charity is currently an initiative of Pulse Stream Media. It is not presented as a registered NPO, NPC or public benefit organisation, and we do not claim tax-deductible status for contributions.</div></div></section>
{sec("focus", "What we focus on", f'<div class="grid g3">{focus}</div>', alt=True)}
{sec("relationship", "Our relationship with Pulse Stream", '<div class="prose"><p>The charity is being developed under Pulse Stream Media and is linked to The Voice Amplified Podcast. Pulse Stream supports it with its media and production skills so that stories, campaigns and reports can be shared clearly.</p><p>Charitable contributions are accounted for separately from Pulse Stream&rsquo;s ordinary commercial revenue.</p></div>')}
{sec("involved", "Get involved", '<div class="grid g3">' + card("Volunteer", "Offer your time and skills to community projects.") + card("Corporate social responsibility", "Partner with us on a project that fits your organisation&rsquo;s CSR goals.") + card("Fundraising campaigns", "Support, or run, a campaign for a specific community need.") + "</div>", alt=True)}
{sec("giving", "Giving and transparency", '<div class="grid g2"><div class="prose"><p>Every contribution is recorded against a campaign-specific reference and tracked separately from commercial payments.</p><p>Banking details are not published on this page. To contribute, email <a href="mailto:donations@pulsestream.africa" style="color:var(--accent)">donations@pulsestream.africa</a> with the campaign you would like to support, and we will reply with payment instructions.</p></div><div class="prose"><p>We commit to publishing transparent summaries of funds received and activities carried out. Figures will appear here only once they are confirmed.</p></div></div>')}
{contact_block(b, ["Make a donation", "Volunteer", "Corporate social responsibility", "Start a campaign", "Other"], "enquiry-charity", "Contact the charity initiative", "Questions, offers of help and partnership ideas are welcome.")}'''
    ld = {"@context": "https://schema.org", "@type": "Organization", "name": "The Voice Amplified Charity", "url": url(b),
          "description": "A community empowerment and social development initiative of Pulse Stream Media.", "parentOrganization": {"@id": "https://pulsestream.africa/#org"}}
    return {"/": dict(title="The Voice Amplified Charity | Community Empowerment Initiative",
            desc="The Voice Amplified Charity is a Pulse Stream community initiative for community development and empowerment. Volunteer, partner or enquire about giving.",
            body=body, schema=[ld], crumbs=None, nav=nav, cta=cta, book_href="#contact")}


def build_music():
    b = "music"
    nav = [("Services", "/#services"), ("Pricing", "/#pricing"), ("How it works", "/#process"), ("Contact", "/#contact")]
    cta = ("Book a session", "/#contact")
    steps = "".join(card(f"{i}. {t}", d) for i, (t, d) in enumerate([
        ("Book", "Tell us about your song or project and your preferred date."),
        ("Record", "Your vocal recording session takes place at the agreed time."),
        ("Mix and master", "Mixing and mastering to prepare your song for release."),
        ("Release", "Receive your final files, ready for the platforms you choose.")], 1))
    body = f'''<section class="hero"><div class="wrap"><div><span class="eyebrow">Music recording in Gauteng</span>
<h1>Pulse Stream Recording</h1><p class="lead">Vocal recording, beat production, mixing and mastering for artists, singers and producers. From a single vocal session to a full song production.</p>
<div class="btn-row"><a class="btn" href="#contact">Book a session</a><a class="btn btn--wa" href="{wa_link("Hello, I would like to book a recording session.")}" rel="noopener">WhatsApp us</a></div></div>
<div class="hero-logo" style="justify-self:center">{logo_tag("pulsestream", 320)}</div></div></section>
{sec("services", "Studio services", '<div class="grid g3">' + card("Vocal recording", "Vocal recording sessions, charged by the hour.") + card("Beat production", "Original beats for your next song.") + card("Mixing and mastering", "Balanced, polished tracks prepared for release.") + card("Vocal editing", "Basic vocal editing to tidy your recordings.") + card("Full song production", "From idea to finished song in one place.") + card("Audio engineering", "Technical audio support for music and media projects.") + "</div>", alt=True)}
{sec("pricing", "Starting prices", price_block("Music production", PRICES["Music production"]) + f'<p class="price-note">{PRICE_NOTE}</p>')}
{sec("process", "How it works", f'<div class="grid g4">{steps}</div>', alt=True)}
{contact_block(b, ["Vocal recording", "Beat production", "Song mixing", "Song mastering", "Full song production", "Other"], "enquiry-music", "Book a recording session", "Tell us about your project and we will confirm availability and a quotation.")}'''
    return {"/": dict(title="Music Recording Studio, Gauteng | Pulse Stream Recording",
            desc="Pulse Stream Recording: vocal recording, beat production, mixing and mastering in Germiston, Gauteng. Starting prices and bookings.",
            body=body, schema=[local_ld(b, "Pulse Stream Recording", "Music recording, mixing and mastering in Gauteng, South Africa.")], crumbs=None, nav=nav, cta=cta, book_href="#contact")}
