import html, json, os
from config import *

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = json.load(open(os.path.join(ROOT, "src", "images.json")))
e = html.escape

WA_SVG = ('<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16.04 3C8.84 3 3 8.83 3 16.02c0 2.3.6 4.54 1.74 6.52L3 29l6.62-1.7a13 13 0 0 0 6.42 1.64h.01c7.19 0 13.03-5.84 13.03-13.02C29.08 8.83 23.23 3 16.04 3zm0 23.7h-.01a10.7 10.7 0 0 1-5.45-1.49l-.39-.23-3.93 1.01 1.05-3.83-.25-.4a10.68 10.68 0 0 1-1.64-5.7c0-5.9 4.8-10.7 10.7-10.7 2.86 0 5.54 1.11 7.56 3.13a10.62 10.62 0 0 1 3.13 7.57c0 5.9-4.8 10.7-10.77 10.7zm5.87-8c-.32-.16-1.9-.94-2.2-1.05-.3-.11-.51-.16-.73.16-.21.32-.83 1.05-1.02 1.26-.19.22-.37.24-.7.08-.32-.16-1.35-.5-2.57-1.58-.95-.85-1.6-1.9-1.78-2.22-.19-.32-.02-.5.14-.66.14-.14.32-.37.48-.56.16-.19.21-.32.32-.54.1-.21.05-.4-.03-.56-.08-.16-.73-1.76-1-2.4-.26-.63-.53-.54-.73-.55h-.62c-.21 0-.56.08-.85.4-.29.32-1.12 1.1-1.12 2.68 0 1.58 1.15 3.1 1.31 3.32.16.21 2.26 3.45 5.48 4.84.77.33 1.37.53 1.83.68.77.24 1.47.21 2.02.13.62-.09 1.9-.78 2.17-1.53.27-.75.27-1.4.19-1.53-.08-.13-.29-.21-.61-.37z"/></svg>')

FONTS = {
    "default": "https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600;700&family=Inter:wght@400;500;600&display=swap",
    "tops": "https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Inter:wght@400;500;600&display=swap",
}


def url(brand, path="/"):
    return f"https://{HOSTS[brand]}{path}"


def picture(key, alt=None, sizes="(max-width:620px) 92vw, 600px", eager=False, widths=None, cls="", default_w=None):
    m = IMG[key]
    ws = [w for w in m["widths"] if (not widths or w in widths)]
    dw = default_w or (ws[1] if len(ws) > 1 else ws[0])
    h = round(m["h"] * dw / m["w"]) if m["w"] else 0
    avif = ", ".join(f"/assets/images/{key}-{w}.avif {w}w" for w in ws)
    webp = ", ".join(f"/assets/images/{key}-{w}.webp {w}w" for w in ws)
    load = 'loading="eager" fetchpriority="high" decoding="async"' if eager else 'loading="lazy" decoding="async"'
    return (f'<picture><source type="image/avif" srcset="{avif}" sizes="{sizes}">'
            f'<source type="image/webp" srcset="{webp}" sizes="{sizes}">'
            f'<img src="/assets/images/{key}-{dw}.webp" width="{dw}" height="{h}" alt="{e(alt or m["alt"])}" {load}'
            f'{" class=%s" % chr(34)+cls+chr(34) if cls else ""}></picture>')


def logo_img(brand, size=38):
    b = BRANDS[brand]
    if b["logo"]:
        W, H = IMG["_logos"][b["logo"]]
        return f'<img src="/assets/brand/{b["logo"]}-logo-sm.webp" width="{min(round(size * W / H), size * 3)}" height="{size}" alt="">'
    mono = "RW" if brand == "ron" else "VA"
    col = "#168f89" if brand == "ron" else "#c9611f"
    return f'<span class="bc-mono" style="width:{size}px;height:{size}px;font-size:.85rem;background:{col};border-radius:50%">{mono}</span>'


def wa_link(text="Hello, I would like to make an enquiry."):
    from urllib.parse import quote
    return f"https://wa.me/{WA_NUMBER}?text={quote(text)}"


def follow_section(brand):
    own = SOCIALS.get(brand)
    if own:
        items = []
        for name, link in own:
            label = ("Subscribe on YouTube" if name == "YouTube" else f"Follow on {name}")
            items.append(f'<a href="{link}" target="_blank" rel="noopener noreferrer">{label}</a>')
        intro = f"Follow and subscribe to {e(BRANDS[brand]['name'])} to keep up with new content."
        title = "Follow and subscribe"
    else:
        items = []
        for b, lst in SOCIALS.items():
            for name, link in lst:
                verb = "Subscribe" if name == "YouTube" else "Follow"
                items.append(f'<a href="{link}" target="_blank" rel="noopener noreferrer">{verb}: {e(BRANDS[b]["short"])} on {name}</a>')
        intro = ("Our brand channels are listed below. Channels for Pulse Stream itself will be added here as they are created.")
        title = "Follow the Pulse Stream family"
    items.append(f'<a href="{wa_link()}" target="_blank" rel="noopener noreferrer">WhatsApp {WA_DISPLAY}</a>')
    return (f'<section class="section section--alt" id="follow" aria-labelledby="follow-h"><div class="wrap">'
            f'<h2 id="follow-h">{title}</h2><p class="lead">{intro}</p><div class="follow">{"".join(items)}</div></div></section>')


def hours_list():
    return '<ul class="info-list">' + "".join(f"<li><span>{a}</span><b>{b}</b></li>" for a, b in HOURS) + "</ul>"


def header(brand, nav, cta, path):
    b = BRANDS[brand]
    links = "".join(f'<a href="{h}"{" aria-current=page" if h == path else ""}>{l}</a>' for l, h in nav)
    mob = "".join(f'<a href="{h}">{l}</a>' for l, h in nav)
    home = "/" if brand == "main" else "/"
    return f'''<header class="site-header"><div class="wrap">
<a class="brand" href="{home}" aria-label="{e(b["name"])} home">{logo_img(brand)}<span>{e(b["short"])}<span class="sub">{e(b["sub"])}</span></span></a>
<nav class="nav" aria-label="Main">{links}<a class="btn" href="{cta[1]}">{cta[0]}</a></nav>
<button class="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-panel"><span></span><span></span><span></span></button>
</div></header>
<div class="overlay" aria-hidden="true"></div>
<aside class="mobile-panel" id="mobile-panel" aria-label="Menu"><button class="close" aria-label="Close menu">&times;</button>{mob}
<a href="{cta[1]}" class="btn" style="margin-top:1rem;border-bottom:0">{cta[0]}</a>
<a href="{wa_link()}" class="btn btn--wa" style="margin-top:.6rem;border-bottom:0" rel="noopener">WhatsApp us</a></aside>'''


def footer(brand, nav):
    b = BRANDS[brand]
    expl = "".join(f'<li><a href="{h}">{l}</a></li>' for l, h in nav)
    fam = "".join(f'<li><a href="{url(k, "/")}">{e(v["name"])}</a></li>' for k, v in BRANDS.items() if k != brand)
    if brand != "main":
        fam = f'<li><a href="{url("main", "/")}">Pulse Stream Media (main site)</a></li>' + fam.replace(
            f'<li><a href="{url("main", "/")}">{e(BRANDS["main"]["name"])}</a></li>', "")
    mails = "".join(f'<li><a href="mailto:{m}">{m}</a></li>' for m in b["emails"])
    addr = f"<li>{ADDRESS_LINE}</li>" if b["show_address"] else ""
    hrs = "".join(f"<li>{a}: {c}</li>" for a, c in HOURS)
    soc = SOCIALS.get(brand)
    socl = "".join(f'<li><a href="{l}" target="_blank" rel="noopener noreferrer">{("Subscribe on " if n == "YouTube" else "Follow on ")}{n}</a></li>' for n, l in (soc or []))
    return f'''<footer class="site-footer"><div class="wrap"><div class="footer-grid">
<div><div class="brand" style="margin-bottom:1rem">{logo_img(brand)}<span>{e(b["name"])}</span></div>
<p style="color:var(--muted);max-width:34ch">A Pulse Stream Media brand. Professional multimedia production in South Africa.</p></div>
<div><div class="fh">Explore</div><ul>{expl}</ul></div>
<div><div class="fh">Our brands</div><ul>{fam}</ul></div>
<div><div class="fh">Contact</div><ul>{addr}<li><a href="{wa_link()}" rel="noopener">WhatsApp {WA_DISPLAY}</a></li>{mails}{socl}</ul>
<div class="fh" style="margin-top:1.2rem">Hours</div><ul>{hrs}</ul></div>
</div><div class="legal"><span>&copy; 2026 Pulse Stream Media. All rights reserved.</span>
<span><a href="{url("main", "/privacy/")}">Privacy notice</a> &middot; <a href="{url("main", "/terms/")}">Terms</a> &middot; Website by <a href="{url("ron", "/")}">Ron Wayez</a></span></div></div></footer>'''


def floating(brand, book_href):
    return (f'<a class="wa-float" href="{wa_link(f"Hello, I would like to enquire about {BRANDS[brand]["name"]}.")}" target="_blank" rel="noopener" '
            f'aria-label="Chat with us on WhatsApp">{WA_SVG}</a>'
            f'<div class="book-bar"><a class="btn" href="{book_href}">Book now</a></div>')


def enquiry_form(brand, services=None, fid="enquiry", heading_id=None):
    b = BRANDS[brand]
    opts = "".join(f'<option value="{e(s)}">{e(s)}</option>' for s in (services or SERVICE_OPTIONS))
    bud = "".join(f'<option value="{e(s)}">{e(s)}</option>' for s in BUDGETS)

    def fld(i, label, typ="text", req=False, tag="input", extra=""):
        r = " required" if req else ""
        star = " *" if req else ""
        ctl = (f'<textarea id="{fid}-{i}" name="{i}"{r}></textarea>' if tag == "textarea" else
               f'<input id="{fid}-{i}" name="{i}" type="{typ}"{r} {extra}>')
        return f'<div class="field{" full" if tag == "textarea" else ""}"><label for="{fid}-{i}">{label}{star}</label>{ctl}<div class="err" role="alert"></div></div>'
    sel = lambda i, label, o, req=False: (f'<div class="field"><label for="{fid}-{i}">{label}{" *" if req else ""}</label>'
                                           f'<select id="{fid}-{i}" name="{i}"{" required" if req else ""}><option value="">Choose…</option>{o}</select><div class="err" role="alert"></div></div>')
    return f'''<form class="form" id="{fid}" data-enquiry data-brand-name="{e(b["name"])}" data-email="{b["contact_email"]}" data-wa="{WA_NUMBER}" novalidate>
{fld("name", "Full name", req=True, extra='autocomplete="name"')}{fld("email", "Email address", "email", True, extra='autocomplete="email"')}
{fld("phone", "WhatsApp / mobile number", "tel", True, extra='autocomplete="tel"')}{fld("company", "Company name (optional)")}
{sel("service", "Service required", opts, True)}{fld("date", "Preferred date", "date")}
{sel("budget", "Budget range", bud)}<div></div>
{fld("message", "Tell us about your project", req=True, tag="textarea")}
<div class="full btn-row" style="margin-top:0"><button class="btn" type="submit">Send by email</button>
<button class="btn btn--wa" type="button" data-send="wa">Send via WhatsApp</button></div>
<div class="full form-success" role="status" aria-live="polite"></div>
<p class="full form-note">This form opens your email app or WhatsApp with your enquiry filled in. It does not store anything on our servers. Your details are used only to respond to your enquiry (see our <a href="{url("main", "/privacy/")}">privacy notice</a>).</p>
</form>'''


def jsonld(*items):
    return "".join(f'<script type="application/ld+json">{json.dumps(i, ensure_ascii=False)}</script>' for i in items)


def breadcrumb_ld(brand, crumbs):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": url(brand, p)} for i, (n, p) in enumerate(crumbs)]}


def crumbs_html(crumbs):
    parts = []
    for i, (n, p) in enumerate(crumbs):
        parts.append(f'<a href="{p}">{e(n)}</a>' if i < len(crumbs) - 1 else f'<span aria-current="page">{e(n)}</span>')
    return f'<nav class="crumbs wrap" aria-label="Breadcrumb">{" / ".join(parts)}</nav>'


def layout(brand, path, title, desc, body, nav, cta, schema=(), crumbs=None, robots="index,follow,max-image-preview:large",
           follow=True, book_href="/contact/", font="default", og_alt=None):
    b = BRANDS[brand]
    canon = url(brand, path)
    og = f"https://{HOSTS[brand]}/assets/brand/og-{brand}.jpg"
    ld = list(schema)
    if crumbs and len(crumbs) > 1:
        ld.append(breadcrumb_ld(brand, crumbs))
    fav = b["fav"]
    return f'''<!doctype html>
<html lang="en-ZA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(title)}</title><meta name="description" content="{e(desc)}"><meta name="robots" content="{robots}">
<link rel="canonical" href="{canon}"><meta name="theme-color" content="#0a0a0a">
<link rel="icon" type="image/png" sizes="48x48" href="/assets/brand/favicon-{fav}.png"><link rel="apple-touch-icon" href="/assets/brand/apple-touch-{fav}.png">
<meta property="og:type" content="website"><meta property="og:site_name" content="{e(b["name"])}"><meta property="og:locale" content="en_ZA">
<meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(desc)}"><meta property="og:url" content="{canon}">
<meta property="og:image" content="{og}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="{e(og_alt or b["name"])}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{e(title)}"><meta name="twitter:description" content="{e(desc)}"><meta name="twitter:image" content="{og}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{FONTS[font]}"><link rel="stylesheet" href="/assets/css/main.css">
{jsonld(*ld)}</head>
<body data-brand="{brand}"><a class="skip" href="#main">Skip to content</a>
{header(brand, nav, cta, path)}
<main id="main">{crumbs_html(crumbs) if crumbs and len(crumbs) > 1 else ""}{body}{follow_section(brand) if follow else ""}</main>
{footer(brand, nav)}{floating(brand, book_href)}
<div class="lightbox" role="dialog" aria-modal="true" aria-label="Image viewer"><button aria-label="Close image">&times;</button><img alt="" width="1" height="1" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="></div>
<script src="/assets/js/main.js" defer></script></body></html>'''
