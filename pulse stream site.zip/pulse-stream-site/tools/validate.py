"""Static QA: run after build. Reports only what is actually checked."""
import json, os, re, sys
from urllib.parse import urlparse
from bs4 import BeautifulSoup
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=ROOT+"/dist"
HOSTS={"pulsestream.africa":"main"}; 
for b in ("optic1","tva","tops","ron","charity","music"): HOSTS[f"{b}.pulsestream.africa"]=b
issues=[]; pages=0; links=0; imgs=0
def page_file(brand,path):
    p=f"{D}/sites/{brand}{path}"
    if path.endswith(".html"): return p
    if path.endswith("/"): return p+"index.html"
    return p
def exists(brand,path):
    path=path.split("#")[0].split("?")[0] or "/"
    if path.startswith("/assets/"): return os.path.exists(D+path)
    if path in("/robots.txt","/sitemap.xml"): return True
    return os.path.exists(page_file(brand,path if path.endswith(("/",".html")) else path+"/"))
for brand in HOSTS.values():
  for root,_,fs in os.walk(f"{D}/sites/{brand}"):
    for f in fs:
      if not f.endswith(".html"): continue
      fp=os.path.join(root,f); rel="/"+os.path.relpath(fp,f"{D}/sites/{brand}").replace("index.html","")
      s=open(fp,encoding="utf-8").read(); soup=BeautifulSoup(s,"html.parser"); pages+=1; tag=f"{brand}{rel}"
      h1=soup.find_all("h1")
      if len(h1)!=1: issues.append(f"{tag}: {len(h1)} H1")
      # heading order
      last=0
      for h in soup.find_all(re.compile("^h[1-6]$")):
          n=int(h.name[1]); 
          if last and n>last+1: issues.append(f"{tag}: heading skip h{last}->h{n}")
          last=n
      t=soup.title.string if soup.title else ""
      if not t or len(t)>62: issues.append(f"{tag}: title len {len(t or '')}")
      d=soup.find("meta",attrs={"name":"description"}); 
      if not d or not (70<=len(d["content"])<=165): issues.append(f"{tag}: description len {len(d['content']) if d else 0}")
      c=soup.find("link",rel="canonical")
      if not c: issues.append(f"{tag}: no canonical")
      else:
          exp=f"https://{[h for h,b in HOSTS.items() if b==brand][0]}{rel if rel!='/404.html' else '/404.html'}"
          if c["href"]!=exp: issues.append(f"{tag}: canonical {c['href']} != {exp}")
      rb=soup.find("meta",attrs={"name":"robots"})["content"]
      if "noindex" in rb and not (rel.endswith("404.html") or "coming-soon" in rel): issues.append(f"{tag}: unexpected noindex")
      for k in ("og:title","og:description","og:image","og:url"):
          if not soup.find("meta",property=k): issues.append(f"{tag}: missing {k}")
      for k in ("twitter:card","twitter:image"):
          if not soup.find("meta",attrs={"name":k}): issues.append(f"{tag}: missing {k}")
      for sc in soup.find_all("script",type="application/ld+json"):
          try: json.loads(sc.string)
          except Exception as ex: issues.append(f"{tag}: bad JSON-LD {ex}")
      for im in soup.find_all("img"):
          imgs+=1
          if im.get("alt") is None: issues.append(f"{tag}: img without alt {im.get('src')}")
          if im.get("src","").startswith("/") and not im["src"].startswith("data:") and not os.path.exists(D+im["src"]): issues.append(f"{tag}: missing img {im['src']}")
          if not im.get("width") or not im.get("height"): issues.append(f"{tag}: img no dimensions {im.get('src')}")
      for so in soup.find_all("source"):
          for part in so["srcset"].split(","):
              u=part.strip().split(" ")[0]
              if not os.path.exists(D+u): issues.append(f"{tag}: missing srcset {u}")
      for a in soup.find_all("a",href=True):
          h=a["href"]; links+=1
          if h.startswith(("mailto:","tel:","javascript:")) : continue
          if h.startswith("#"): 
              if h!="#" and not soup.find(id=h[1:]): issues.append(f"{tag}: dead anchor {h}")
              continue
          if h.startswith("http"):
              u=urlparse(h)
              if u.netloc in HOSTS:
                  tb=HOSTS[u.netloc]; 
                  if not exists(tb,u.path or "/"): issues.append(f"{tag}: broken internal link {h}")
                  frag=u.fragment
                  if frag:
                      tp=open(page_file(tb,u.path or "/"),encoding="utf-8").read()
                      if f'id="{frag}"' not in tp: issues.append(f"{tag}: missing anchor {h}")
              continue
          if not h.startswith("/"): issues.append(f"{tag}: relative/odd href {h}"); continue
          if h.startswith("/"):
              if not exists(brand,h): issues.append(f"{tag}: broken link {h}")
              if "#" in h:
                  p,fr=h.split("#",1); tp=open(page_file(brand,p or rel),encoding="utf-8").read()
                  if f'id="{fr}"' not in tp: issues.append(f"{tag}: missing anchor {h}")
      for lab in soup.find_all("form"):
          for inp in lab.find_all(["input","select","textarea"]):
              if not soup.find("label",attrs={"for":inp.get("id")}): issues.append(f"{tag}: input without label {inp.get('name')}")
      ids=[x["id"] for x in soup.find_all(id=True)]
      if len(ids)!=len(set(ids)): issues.append(f"{tag}: duplicate ids {[i for i in set(ids) if ids.count(i)>1]}")
      # secrets check
      if re.search(r"\b(?!27621834708\b)\d{10,12}\b|api[_-]?key|password",s,re.I): issues.append(f"{tag}: possible secret string")
      if "<img" in s and "YOUR_" in s: issues.append(f"{tag}: placeholder text")
print(f"pages checked: {pages}; links: {links}; img tags: {imgs}")
print("ISSUES:",len(issues)); [print(" -",i) for i in issues[:60]]
