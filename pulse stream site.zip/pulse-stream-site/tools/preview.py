"""Local preview that mimics the vercel.json host rewrites. python3 tools/preview.py [port]"""
import http.server, os, sys, mimetypes
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D=ROOT+"/dist"
H={"pulsestream.africa":"main"}
for b in ("optic1","tva","tops","ron","charity","music"): H[f"{b}.pulsestream.africa"]=b
class R(http.server.BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        host=(self.headers.get("Host") or "").split(":")[0]; path=self.path.split("?")[0]
        brand=H.get(host)
        if not brand and host in('localhost','127.0.0.1'): brand='main'
        if not brand and host.endswith('.localhost') and host.split('.')[0] in H.values(): brand=host.split('.')[0]
        fp=None
        if path.startswith("/assets/"): fp=D+path
        elif brand:
            if path=="/": fp=f"{D}/sites/{brand}/index.html"
            elif path in("/robots.txt","/sitemap.xml"): fp=f"{D}/sites/{brand}{path}"
            else:
                p=f"{D}/sites/{brand}{path}"
                fp=p+"index.html" if path.endswith("/") else p
        if not fp or not os.path.isfile(fp):
            fp=f"{D}/404.html"; code=404
        else: code=200
        data=open(fp,"rb").read(); ct=mimetypes.guess_type(fp)[0] or "text/html"
        self.send_response(code); self.send_header("Content-Type",ct+("; charset=utf-8" if ct.startswith("text") else "")); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
if __name__=="__main__":
    http.server.ThreadingHTTPServer(("127.0.0.1",int(sys.argv[1]) if len(sys.argv)>1 else 8099),R).serve_forever()
