"""Process the owner's photographs and logos into web-optimised assets.

- Originals are never modified (read-only source folder).
- Retouching is limited to global, conservative corrections (tone normalisation,
  output sharpening). No local edits, no face edits, no generative changes.
- Writes assets/images/*.avif|webp and src/images.json (consumed by build.py).
"""
import csv, hashlib, json, os, sys, warnings
from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageFilter, ImageOps

warnings.simplefilter("ignore")
Image.MAX_IMAGE_PIXELS = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = "/home/claude/orig/pulse-stream-website/Images"
UP = "/mnt/user-data/uploads"
OUT = os.path.join(ROOT, "assets", "images")
BRAND = os.path.join(ROOT, "assets", "brand")
WIDTHS = [480, 800, 1200, 1600]

# key, original file, category, destination brands, alt text
PHOTOS = [
    ("corporate-portrait-grey-coat", "foto_no_exif.jpg", "Corporate", ["main", "optic1"],
     "Corporate studio portrait of a bearded man in a grey coat with arms crossed"),
    ("lifestyle-street-white-suit", "foto_no_exif (1).jpg", "Lifestyle", ["main", "optic1"],
     "Lifestyle portrait of a woman in a white suit and sunglasses on a city street"),
    ("family-studio-group-portrait", "foto_no_exif (2).jpg", "Family", ["main", "optic1"],
     "Seven-member family posed together in matching white tops on a grey studio set"),
    ("group-portrait-three-girls", "foto_no_exif (3).jpg", "Family", ["optic1"],
     "Three girls lying side by side with chins on their hands against a grey studio backdrop"),
    ("corporate-headshot-navy-blazer-pose", "foto_no_exif (4).jpg", "Corporate", ["optic1"],
     "Professional headshot of a woman in a navy blazer and blue polo neck on a white backdrop"),
    ("corporate-headshot-navy-blazer-arms-crossed", "foto_no_exif (5).jpg", "Corporate", ["main", "optic1"],
     "Business portrait of a woman in a navy blazer with arms crossed, smiling, on a white backdrop"),
    ("portrait-black-vest-dark-backdrop", "foto_no_exif (6).jpg", "Portraits", ["main", "optic1"],
     "Studio portrait of a woman in a black waistcoat and white blouse against a dark backdrop"),
    ("portrait-black-vest-grey-backdrop", "foto_no_exif (7).jpg", "Portraits", ["optic1"],
     "Studio portrait of a woman in a black waistcoat with hands clasped on a light grey backdrop"),
    ("event-golf-day-gazebo-group-a", "foto_no_exif (8).jpg", "Events", ["main", "optic1"],
     "Group of guests standing at a branded gazebo at an outdoor golf day event"),
    ("event-golf-day-gazebo-group-b", "foto_no_exif (9).jpg", "Events", ["optic1"],
     "Guests gathered under a white gazebo with flags on a green at a golf day event"),
    ("family-group-portrait-brown-backdrop", "foto_no_exif (10).jpg", "Family", ["optic1"],
     "Group portrait of four girls in white tops and jeans against a brown studio backdrop"),
]
DUPLICATE_SKIPPED = ("foto_no_exif (11).jpg", "Exact duplicate of foto_no_exif (3).jpg (identical SHA-256); not used")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def retouch(im):
    """Conservative global correction only."""
    im = ImageOps.exif_transpose(im).convert("RGB")
    return ImageOps.autocontrast(im, cutoff=0.15, preserve_tone=True)


def save_set(im, key, widths=WIDTHS):
    made = []
    for w in widths:
        if w > im.width and made:
            continue
        w = min(w, im.width)
        h = round(im.height * w / im.width)
        r = im.resize((w, h), Image.LANCZOS).filter(ImageFilter.UnsharpMask(0.7, 35, 3))
        r.save(os.path.join(OUT, f"{key}-{w}.webp"), "WEBP", quality=78, method=6)
        r.save(os.path.join(OUT, f"{key}-{w}.avif"), "AVIF", quality=52, speed=7)
        made.append(w)
    return made


def photos():
    manifest, rows = {}, []
    for key, fn, cat, dest, alt in PHOTOS:
        path = os.path.join(SRC, fn)
        with Image.open(path) as im:
            fmt, size = im.format, im.size
            im.draft("RGB", (WIDTHS[-1] * 2, WIDTHS[-1] * 3))
            work = retouch(im)
        # Normalise to max 1600 wide before sets so huge sources are cheap
        if work.width > 1800:
            work = work.resize((1800, round(work.height * 1800 / work.width)), Image.LANCZOS)
        ws = save_set(work, key)
        manifest[key] = {"widths": ws, "w": work.width, "h": work.height, "alt": alt,
                         "category": cat, "dest": dest}
        note = "Mislabelled: file is WebP with .jpg extension; appears upscaled" if fmt == "WEBP" else ""
        rows.append([fn, fmt, f"{size[0]}x{size[1]}", os.path.getsize(path), sha(path),
                     "No EXIF/IPTC/XMP/GPS present (already stripped)", "CLEARED (ownership confirmed by owner)",
                     cat, "Global tone normalisation + output sharpening; no face/local edits",
                     f"{key}-*.avif/.webp", "assets/images/", note])
        print("done", key, ws, file=sys.stderr)
    fn, note = DUPLICATE_SKIPPED
    p = os.path.join(SRC, fn)
    rows.append([fn, "JPEG", "6048x4024", os.path.getsize(p), sha(p), "No metadata present", "CLEARED (ownership confirmed)",
                 "Family", "n/a", "not used", "n/a", note])
    with open(os.path.join(ROOT, "docs", "asset-inventory.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Original filename", "Format", "Dimensions", "Bytes", "SHA-256", "Metadata findings",
                    "Copyright status", "Category", "Retouching", "Final filename", "Folder", "Notes"])
        w.writerows(rows)
    return manifest


def fit(im, box, bg=None):
    im = im.copy()
    im.thumbnail(box, Image.LANCZOS)
    return im


def logos():
    """Brand logos for nav + favicons."""
    out = {}
    def webp(im, name, size):
        r = fit(im, (size, size)); r.save(os.path.join(BRAND, name + ".webp"), "WEBP", quality=85, method=6)
        r.save(os.path.join(BRAND, name + ".png"), optimize=True)
        out[name] = list(r.size)
    ps = Image.open(os.path.join(UP, "Pulsestream_Logo.png")).convert("RGBA")
    va = Image.open(os.path.join(UP, "The_Voice_Amplified_Podcast_logo.png")).convert("RGBA")
    tp = Image.open(os.path.join(UP, "Thoughts_and_othe_problems_podcast_logo.jpeg")).convert("RGB")
    op = Image.open(os.path.join(UP, "OPTIC_1_Media_Logo__1_.png")).convert("RGB")
    # crop to content
    ps = ps.crop(ps.getbbox()); va = va.crop(va.getchannel("A").point(lambda a: 255 if a > 20 else 0).getbbox())
    bgc = Image.new("RGB", op.size, (6, 10, 19))
    diff = ImageOps.autocontrast(Image.eval(ImageChops.difference(op, bgc).convert("L"), lambda v: 255 if v > 40 else 0))
    box = diff.getbbox(); pad = 160
    box = (max(0, box[0] - pad), max(0, box[1] - pad), min(op.width, box[2] + pad), min(op.height, box[3] + pad))
    op_l = op.crop(box)
    if op_l.width > 1250: op_l = op_l.resize((1250, round(op_l.height * 1250 / op_l.width)), Image.LANCZOS)
    for im, n in ((ps, "pulsestream"), (va, "tva"), (tp, "tops"), (op_l, "optic1")):
        webp(im, n + "-logo", 512)
        webp(im, n + "-logo-sm", 160)
    return {"pulsestream": ps, "tva": va, "tops": tp, "optic1": op_l}


def favicon(name, im, bg, mono=None):
    s = 512
    base = Image.new("RGB", (s, s), bg)
    if mono:
        d = ImageDraw.Draw(base)
        f = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 230)
        tw = d.textlength(mono, font=f)
        d.text(((s - tw) / 2, 120), mono, font=f, fill=(255, 255, 255))
    else:
        l = fit(im.convert("RGBA"), (int(s * .8), int(s * .8)))
        base.paste(l, ((s - l.width) // 2, (s - l.height) // 2), l)
    base.save(os.path.join(BRAND, f"favicon-{name}-512.png"), optimize=True)
    base.resize((180, 180), Image.LANCZOS).save(os.path.join(BRAND, f"apple-touch-{name}.png"), optimize=True)
    base.resize((48, 48), Image.LANCZOS).save(os.path.join(BRAND, f"favicon-{name}.png"), optimize=True)


def og(name, title, tagline, bg, accent, logo_im, logo_bg_is_dark=True):
    W, H = 1200, 630
    img = Image.new("RGB", (W, H), bg)
    d = ImageDraw.Draw(img)
    d.rectangle([0, H - 14, W, H], fill=accent)
    L = fit(logo_im.convert("RGBA"), (400, 400))
    img.paste(L, (70, (H - L.height) // 2), L)
    ft = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 62)
    fs = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Regular.otf", 30)
    x, y = 520, 190
    for line in title.split("\n"):
        d.text((x, y), line, font=ft, fill=(255, 255, 255)); y += 76
    d.text((x, y + 14), tagline, font=fs, fill=(200, 200, 200))
    d.text((x, H - 70), "pulsestream.africa", font=ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Medium.otf", 26), fill=accent)
    img.save(os.path.join(BRAND, f"og-{name}.jpg"), quality=86, optimize=True, progressive=True)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True); os.makedirs(BRAND, exist_ok=True)
    man = photos()
    L = logos()
    favicon("main", L["pulsestream"], (10, 10, 10))
    favicon("optic1", L["optic1"], (6, 10, 19))
    favicon("tva", L["tva"], (11, 11, 13))
    favicon("tops", L["tops"], (0, 0, 0))
    favicon("ron", None, (17, 17, 17), mono="RW")
    favicon("charity", None, (42, 33, 24), mono="VA")
    favicon("music", L["pulsestream"], (10, 10, 10))
    og("main", "Pulse Stream Media", "Photography · Video · Podcasts · Music · Events", (10, 10, 10), (59, 179, 172), L["pulsestream"])
    og("optic1", "OPTIC1 Media", "Professional photography in Gauteng", (6, 10, 19), (255, 160, 51), L["optic1"])
    og("tva", "The Voice\nAmplified Podcast", "Amplifying Voices. Inspiring Change.", (11, 11, 13), (232, 116, 44), L["tva"])
    og("tops", "Thoughts and\nOther Problems", "An African feminine podcast", (0, 0, 0), (200, 85, 61), L["tops"])
    og("ron", "Ron Wayez", "Web design · Development · Creative direction", (17, 17, 17), (59, 179, 172), Image.open(os.path.join(BRAND, "favicon-ron-512.png")))
    og("charity", "The Voice Amplified\nCharity", "A Pulse Stream community initiative", (42, 33, 24), (232, 116, 44), Image.open(os.path.join(BRAND, "favicon-charity-512.png")))
    og("music", "Pulse Stream\nRecording", "Recording · Mixing · Mastering", (10, 10, 10), (232, 116, 44), L["pulsestream"])
    man["_logos"] = L and {k: list(v.size) for k, v in L.items()}
    json.dump(man, open(os.path.join(ROOT, "src", "images.json"), "w"), indent=1)
    print("OK")
