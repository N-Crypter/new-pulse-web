import json, sys
from playwright.sync_api import sync_playwright
HOSTS=["pulsestream.africa","optic1.pulsestream.africa","tva.pulsestream.africa","tops.pulsestream.africa","ron.pulsestream.africa","charity.pulsestream.africa","music.pulsestream.africa"]
EXTRA=["pulsestream.africa/pricing/","pulsestream.africa/podcast-studio/","pulsestream.africa/portfolio/","pulsestream.africa/services/","pulsestream.africa/about/","pulsestream.africa/contact/","pulsestream.africa/faq/","pulsestream.africa/videography/","pulsestream.africa/pa-events/","pulsestream.africa/privacy/","pulsestream.africa/terms/","pulsestream.africa/coming-soon/","pulsestream.africa/nope/"]
res=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--host-resolver-rules=MAP *.pulsestream.africa 127.0.0.1:8099, MAP pulsestream.africa 127.0.0.1:8099"])
    for vp,name in (({"width":1440,"height":900},"desk"),({"width":820,"height":1100},"tab"),({"width":390,"height":844},"mob")):
        ctx=b.new_context(viewport=vp, device_scale_factor=1, is_mobile=(name=="mob")); 
        for u in [h+"/" for h in HOSTS]+EXTRA:
            pg=ctx.new_page(); errs=[]; fails=[]
            pg.on("console",lambda m,errs=errs: errs.append(m.text) if m.type=="error" else None)
            pg.on("pageerror",lambda e,errs=errs: errs.append("PAGEERR "+str(e)))
            pg.on("requestfailed",lambda r,fails=fails: fails.append(r.url))
            pg.on("response",lambda r,fails=fails: fails.append(f"{r.status} {r.url}") if r.status>=400 and "nope" not in r.url else None)
            pg.goto("http://"+u+":8099" if False else "http://"+u.replace("/",":8099/",1),wait_until="load")
            pg.wait_for_timeout(300)
            pg.evaluate("window.scrollTo(0,document.body.scrollHeight)"); pg.wait_for_timeout(400); pg.evaluate("window.scrollTo(0,0)")
            m=pg.evaluate("""()=>{const bad=[...document.images].filter(i=>i.complete&&i.naturalWidth===0&&i.currentSrc&&!i.currentSrc.startsWith('data:')).map(i=>i.currentSrc);
              const doc=document.documentElement; const wa=document.querySelector('.wa-float'); const r=wa.getBoundingClientRect();
              return {overflowX: doc.scrollWidth>doc.clientWidth+1, scrollW:doc.scrollWidth, clientW:doc.clientWidth, brokenImgs:bad, waVisible:r.width>0&&r.bottom<=innerHeight+1&&r.right<=innerWidth+1, h1:document.querySelectorAll('h1').length, emptyFigs:[...document.querySelectorAll('.gallery figure img,.hero-media img')].filter(i=>!i.complete||i.naturalWidth===0).length}}""")
            fails=[f for f in fails if "fonts.g" not in f]; errs=[e for e in errs if "fonts.g" not in e and "ERR_" not in e and "Failed to load resource" not in e]
            res.append((name,u,m,errs,fails))
            if name in("desk","mob") and (u.count("/")<=1 or u.endswith(("pricing/","podcast-studio/","portfolio/"))):
                pg.screenshot(path=f"/home/claude/shots/{name}-{u.split('.')[0] if '/' in u and u.count('/')<=1 else u.split('/')[1]}.png",full_page=True)
            pg.close()
        ctx.close()
    b.close()
bad=0
for name,u,m,errs,fails in res:
    flag = m["overflowX"] or m["brokenImgs"] or not m["waVisible"] or m["h1"]!=1 or errs or fails or m["emptyFigs"]
    if flag and "nope" not in u and "coming" not in u: bad+=1; print("FLAG",name,u,{k:v for k,v in m.items() if v not in(False,0,[])},errs[:2],fails[:3])
    if "nope" in u: print("404 test:",name,u,"h1",m["h1"],"fails",fails)
print("viewport/page combos tested:",len(res),"flagged:",bad)
