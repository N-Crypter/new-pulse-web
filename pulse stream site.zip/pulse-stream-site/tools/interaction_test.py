from playwright.sync_api import sync_playwright
R=[]
def ok(n,c): R.append((n,bool(c))); 
with sync_playwright() as p:
    b=p.chromium.launch(args=["--host-resolver-rules=MAP *.pulsestream.africa 127.0.0.1:8099, MAP pulsestream.africa 127.0.0.1:8099"])
    # mobile nav
    pg=b.new_context(viewport={"width":390,"height":844},is_mobile=True).new_page(); pg.goto("http://pulsestream.africa:8099/")
    pg.click(".nav-toggle"); pg.wait_for_timeout(400)
    ok("mobile menu opens", pg.eval_on_selector("#mobile-panel","e=>e.classList.contains('is-open')"))
    pg.click("#mobile-panel a[href='/pricing/']"); ok("menu closes after link", not pg.eval_on_selector("#mobile-panel","e=>e.classList.contains('is-open')")) 
    pg.wait_for_timeout(300); ok("navigated to pricing", pg.url.endswith("/pricing/"))
    pg.goto("http://pulsestream.africa:8099/"); pg.click(".nav-toggle"); pg.click(".overlay",position={"x":10,"y":300}); pg.wait_for_timeout(350)
    ok("overlay click closes menu", not pg.eval_on_selector("#mobile-panel","e=>e.classList.contains('is-open')"))
    # gallery filter + lightbox (desktop)
    pg=b.new_context(viewport={"width":1440,"height":900}).new_page(); pg.goto("http://optic1.pulsestream.africa:8099/")
    n_all=pg.eval_on_selector_all("#gallery-optic1 figure:not([hidden])","e=>e.length")
    pg.click("[data-filters] button[data-filter='Events']"); 
    n_ev=pg.eval_on_selector_all("#gallery-optic1 figure:not([hidden])","e=>e.length")
    ok(f"filter all={n_all} events={n_ev}", n_all==10 and n_ev==2)
    pg.click("[data-filters] button[data-filter='all']")
    pg.click("#gallery-optic1 figure:first-child button"); pg.wait_for_timeout(300)
    ok("lightbox opens with image", pg.eval_on_selector(".lightbox","e=>e.classList.contains('is-open')") and "1600.webp" in pg.eval_on_selector(".lightbox img","e=>e.src"))
    pg.keyboard.press("Escape"); ok("Esc closes lightbox", not pg.eval_on_selector(".lightbox","e=>e.classList.contains('is-open')"))
    # form validation
    pg.goto("http://optic1.pulsestream.africa:8099/#contact"); pg.click("#enquiry-optic1 button[type=submit]")
    inv=pg.eval_on_selector_all("#enquiry-optic1 .field.is-invalid","e=>e.length")
    ok(f"empty form shows {inv} errors", inv==5)
    pg.fill("#enquiry-optic1-name","Test"); pg.fill("#enquiry-optic1-email","bad"); pg.fill("#enquiry-optic1-phone","12"); pg.select_option("#enquiry-optic1-service",index=1); pg.fill("#enquiry-optic1-message","Hi")
    pg.click("#enquiry-optic1 button[type=submit]")
    ok("bad email/phone rejected", pg.eval_on_selector_all("#enquiry-optic1 .field.is-invalid","e=>e.length")==2)
    pg.fill("#enquiry-optic1-email","a@b.co"); pg.fill("#enquiry-optic1-phone","+27 62 183 4708")
    cap={}
    pg.context.route("https://wa.me/**",lambda r:(cap.setdefault("u",r.request.url), r.abort()))
    with pg.expect_popup() as pop: pg.click("#enquiry-optic1 [data-send=wa]")
    pg.wait_for_timeout(600)
    ok("WhatsApp opens in new tab with number and message", "wa.me/27621834708" in (cap.get("u") or pop.value.url) and "Test" in (cap.get("u") or pop.value.url))
    ok("valid form shows success message", "WhatsApp" in pg.eval_on_selector("#enquiry-optic1 .form-success","e=>e.textContent") and pg.eval_on_selector("#enquiry-optic1 .form-success","e=>e.classList.contains('is-visible')"))
    # WA float fixed while scrolling
    pg.goto("http://tops.pulsestream.africa:8099/"); pg.evaluate("window.scrollTo(0,1500)"); pg.wait_for_timeout(200)
    r=pg.eval_on_selector(".wa-float","e=>{const r=e.getBoundingClientRect();return [r.bottom<=innerHeight,r.top>0,e.href]}")
    ok("WhatsApp button stays on screen after scroll", r[0] and r[1] and "wa.me/27621834708" in r[2])
    import urllib.request
    def get(host,path):
        return urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:8099"+path,headers={"Host":host})).read().decode()
    for h in ("pulsestream.africa","optic1.pulsestream.africa","tva.pulsestream.africa","tops.pulsestream.africa","ron.pulsestream.africa","charity.pulsestream.africa","music.pulsestream.africa"):
        r=get(h,"/robots.txt"); sm=get(h,"/sitemap.xml")
        locs=[l.split("</loc>")[0] for l in sm.split("<loc>")[1:]]
        ok(f"robots+sitemap correct for {h} ({len(locs)} urls)", f"https://{h}/sitemap.xml" in r and all(l.startswith(f"https://{h}/") for l in locs) and not any("coming-soon" in l or "404" in l for l in locs))
    b.close()
for n,c in R: print("PASS" if c else "FAIL",n)
