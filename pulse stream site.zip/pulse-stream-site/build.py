"""Static site generator for the Pulse Stream ecosystem. Usage: python3 build.py  -> dist/
One codebase, seven hosts. dist/sites/<brand>/ holds each host's pages; vercel.json maps hosts to folders."""
import json, os, shutil, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from pages_brands import *

DIST = os.path.join(ROOT, "dist")
if os.path.isdir(DIST):
    shutil.rmtree(DIST)
os.makedirs(DIST + "/assets")
shutil.copytree(ROOT + "/static/css", DIST + "/assets/css")
shutil.copytree(ROOT + "/static/js", DIST + "/assets/js")
shutil.copytree(ROOT + "/assets/images", DIST + "/assets/images")
shutil.copytree(ROOT + "/assets/brand", DIST + "/assets/brand")

SITES = {"main": build_main(), "optic1": build_optic1(), "tva": build_tva(), "tops": build_tops(),
         "ron": build_ron(), "charity": build_charity(), "music": build_music()}


def out_path(brand, path):
    base = f"{DIST}/sites/{brand}"
    if path.endswith(".html"):
        return base + path
    return base + path + "index.html"


count = 0
for brand, pages in SITES.items():
    indexable = []
    for path, p in pages.items():
        nav = p.get("nav", NAV_MAIN); cta = p.get("cta", CTA_MAIN)
        robots = p.get("robots", "index,follow,max-image-preview:large")
        html = layout(brand, path, p["title"], p["desc"], p["body"], nav, cta, schema=p.get("schema", ()), crumbs=p.get("crumbs"),
                      robots=robots, follow=p.get("follow", True), book_href=p.get("book_href", "/contact/"), font=p.get("font", "default"))
        fp = out_path(brand, path)
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        open(fp, "w", encoding="utf-8").write(html)
        count += 1
        if robots.startswith("index"):
            indexable.append(path)
    host = HOSTS[brand]
    sm = ('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
          "".join(f"  <url><loc>https://{host}{p}</loc><lastmod>{TODAY}</lastmod></url>\n" for p in sorted(indexable)) + "</urlset>\n")
    open(f"{DIST}/sites/{brand}/sitemap.xml", "w").write(sm)
    open(f"{DIST}/sites/{brand}/robots.txt", "w").write(f"User-agent: *\nAllow: /\n\nSitemap: https://{host}/sitemap.xml\n")

shutil.copy(f"{DIST}/sites/main/404.html", f"{DIST}/404.html")

# vercel.json: one project, host-based rewrites. Filesystem (/assets/*) is served before rewrites.
rewrites = []
for brand, host in HOSTS.items():
    has = [{"type": "host", "value": host}]
    for src, dst in (("/robots.txt", "/sites/%s/robots.txt"), ("/sitemap.xml", "/sites/%s/sitemap.xml"),
                     ("/", "/sites/%s/index.html"), ("/:path*", "/sites/%s/:path*")):
        rewrites.append({"source": src, "has": has, "destination": dst % brand})
cfg = {"$schema": "https://openapi.vercel.sh/vercel.json", "outputDirectory": "dist", "buildCommand": None, "framework": None,
       "trailingSlash": True, "cleanUrls": False,
       "redirects": [{"source": "/:path*", "has": [{"type": "host", "value": "www.pulsestream.africa"}],
                      "destination": "https://pulsestream.africa/:path*", "permanent": True}],
       "rewrites": rewrites,
       "headers": [
           {"source": "/(.*)", "headers": [
               {"key": "Strict-Transport-Security", "value": "max-age=63072000; includeSubDomains"},
               {"key": "X-Content-Type-Options", "value": "nosniff"},
               {"key": "Referrer-Policy", "value": "strict-origin-when-cross-origin"},
               {"key": "X-Frame-Options", "value": "SAMEORIGIN"}]},
           {"source": "/assets/(.*)", "headers": [{"key": "Cache-Control", "value": "public, max-age=31536000, immutable"}]},
           {"source": "/sites/(.*)", "headers": [{"key": "X-Robots-Tag", "value": "noindex"}]}]}
json.dump(cfg, open(ROOT + "/vercel.json", "w"), indent=2)
print("built", count, "pages;", sum(len(v) for v in SITES.values()), "total")
